package com.enwan.miniproject.model;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "user")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long Id;
	
	@Column(name = "firstName", length = 20)
	@NotEmpty(message = "First name should not be empty.")
	private String firstName;
	
	@Column(name = "middleName", length = 20)
	private String middleName;

	@Column(name = "lastName", length = 20)
	@NotEmpty(message = "Last name should not be empty. ")
	private String lastName;
	
	@Column(name = "username", unique = true, length = 20)
	@NotEmpty(message = "Username should not be empty")
	private String username;
	
	@Column(name = "password", length = 255)
	@NotEmpty(message = "Password should not be empty")
	private String password;
	
	@Column(name = "isActive")
	private int isActive;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "role_id", nullable = false)
	private Role roles;
	
	@OneToMany(mappedBy = "user")
	private Set<PlanMember> user_plan = new HashSet<PlanMember>();
	
	public User() {}

	public User(Long id, @NotEmpty(message = "First name should not be empty.") String firstName, String middleName,
			@NotEmpty(message = "Last name should not be empty. ") String lastName,
			@NotEmpty(message = "Username should not be empty") String username,
			@NotEmpty(message = "Password should not be empty") String password, int isActive, Role roles) {
		Id = id;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.username = username;
		this.password = password;
		this.isActive = isActive;
		this.roles = roles;
	}

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public Role getRoles() {
		return roles;
	}

	public void setRoles(Role roles) {
		this.roles = roles;
	}

	
}