package com.enwan.miniproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
	
	@GetMapping("/")
	public String index(Model model) {
		return loadPage(model, "trainee/index", "Trainee Program Plan | Trainees", "extra", false);
	}
	
	@GetMapping("/report")
	public String report(Model model) {
		return loadPage(model, "trainee/report", "Trainee Daily Report | Trainees", "extra", true);
	}
	
	@GetMapping("/login")
	public String login(Model model) {
		model.addAttribute("title", "Login | Bootcamp Tracking System");
		return "main/login";
	}

	@GetMapping("/admin/report")
	public String adminReport(Model model) {
		return loadPage(model, "admin/user", "Trainee Daily Report", "require_table", true);
		
	}

	private String loadPage(Model model, String content, String title, String required, boolean require_table) {
		model.addAttribute("content", content);
		model.addAttribute("title", title);
		model.addAttribute(required, require_table);
		
		return "layouts/template";
	}
	
}
