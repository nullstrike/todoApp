package com.enwan.miniproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
	
	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("content", "trainee/index");
		model.addAttribute("title", "Trainee Program Plan | Bootcamp Tracking System");
		return "layouts/template";
	}
	
	@GetMapping("/report")
	public String report(Model model) {
		model.addAttribute("content", "trainee/report");
		model.addAttribute("title", "Trainee Daily Report | Bootcamp Tracking System");
		model.addAttribute("extra", true);
		return "layouts/template";
	}
	
	@GetMapping("/login")
	public String login(Model model) {
		model.addAttribute("title", "Login | Bootcamp Tracking System");
		return "main/login";
	}

	@GetMapping("/admin/report")
	public String adminReport(Model model) {
		model.addAttribute("content", "admin/user");
		model.addAttribute("title", "Trainee Daily Report | Bootcamp Tracking System");
		model.addAttribute("require_table", true);
		
		return "layouts/template";
		
	}
	
}
