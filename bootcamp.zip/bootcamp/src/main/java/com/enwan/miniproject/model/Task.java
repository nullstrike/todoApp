package com.enwan.miniproject.model;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@Table(name = "`task`")
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "task_id")
	private int Id;
	
	@Column(name = "task_text")
	@Type(type = "text")
	private String Task;
	
	@Column(name = "task_type", length = 50)
	private String task_type;
	
	@ManyToOne(optional = false, cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "user_id", foreignKey = @ForeignKey(name = "FK_UserTask"))
	private User user;
	
	@Column(name = "task_date")
	@Temporal(TemporalType.DATE)
	private Date task_date;

	public Task(int id, String task, String task_type, User user, Date task_date) {
		Id = id;
		Task = task;
		this.task_type = task_type;
		this.user = user;
		this.task_date = task_date;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getTask() {
		return Task;
	}

	public void setTask(String task) {
		Task = task;
	}

	public String getTask_type() {
		return task_type;
	}

	public void setTask_type(String task_type) {
		this.task_type = task_type;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getTask_date() {
		return task_date;
	}

	public void setTask_date(Date task_date) {
		this.task_date = task_date;
	}
	
	
}
