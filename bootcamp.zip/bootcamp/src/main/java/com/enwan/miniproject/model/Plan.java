package com.enwan.miniproject.model;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "plan")
public class Plan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "plan_id")
	private Long Id;
	
	@Column(name = "name", length = 255, nullable = false)
	private String name;
	
	@Column(name = "start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name = "end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	 @ManyToMany(cascade = CascadeType.ALL)
	 @JoinTable(name = "plan_modules", joinColumns = {
			 		@JoinColumn(name = "module_id", nullable = false, updatable = false)},
	 		   inverseJoinColumns = { 
	 				   @JoinColumn(name = "plan_id", nullable = false, updatable = false)
	 })
	private Set<Module> module = new HashSet<Module>();
	
	@OneToMany(mappedBy = "plan", cascade = CascadeType.ALL)
	private Set<PlanMember> planmember = new HashSet<PlanMember>();

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	
	
}
