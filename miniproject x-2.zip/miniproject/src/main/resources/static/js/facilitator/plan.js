$(document).ready(function(){
	var planName = $("input[name=planName]");
	var planId;
	var module_id, plan_id;
	var instructor = $("input[name=instructor]");
	var startDate = $("#detailstartDate");
	var endDate = $("#detailendDate");
	var user_id = parseInt($("#user_id").text());
	var dateFormat = "MM dd, yy";
	var users = [];
	
	var startDateOpts = {
			defaultDate: "+1w",
			dateFormat : "MM dd, yy",
			minDate: new Date(),
			altFormat: "yy-mm-dd",
			altField: "#detailstartDate"
		};
	
	var endDateOpts = {
			defaultDate: "+1w",
			dateFormat : "MM dd, yy",
			minDate: new Date(),
			altFormat: "yy-mm-dd",
			altField: "#detailendDate"
		};
	
		
	var from = $('.startDate').datepicker(startDateOpts).on("change", function() {
		to.datepicker("option", "minDate", datepickerParse(this))
	});
	
	var to = $('.endDate').datepicker(endDateOpts).on("change", function() {
		from.datepicker("option", "maxDate", datepickerParse(this))
	});
	
	
	  $.contextMenu({
          selector: '.context-menu-one', 
          items: {
              "edit": {
            	  		name: "Edit Plan", 
            	  		icon: "edit",
            	  		callback: function(key, options){
            	  			var planText = $(options.$trigger[0]).text();
            	  			planId = $(options.$trigger[0]).data('id');
            	  			var userPlan = $("#trainee_list");
            	  			
            	  			$.ajax({
            	  			    type: 'GET',
            	  			    url: 'http://localhost:8080/api/user/plan/' + planId
            	  			}).then(function (response) {
	            	  			var list = [];
	            	  			for (var data in response){
	            	  				var template = "<li class='list-group-item' data-id='"+ response[data].id +"'>" + response[data].text +
	            	  				"<span class='float-right'><span class='btn btn-sm text-danger remove-plan'>" +
			                            "<span class='fas fa-trash fa-lg'></span></span></span></li>";
	            	  				list.push(template);
	            	  				
	            	  			}
	            	  			$("#planName").val(planText);
	            	  		
	            	  			userPlan.html(list);
	            	  			
            	  			});
            	  			
            	  			$("#planModal .modal-title").text("Update Plan");
            	  			$("#savePlan").hide();
            	  			$("#trainee_list_wrapper").show();
            	  			$("#updatePlan").prop("hidden", false);
            	  			$("#planModal").modal('show');
            	  		}},
              "delete": {name: "Delete Plan", icon: "delete", callback: function(key, options){
            	
  	  			var id = options.$trigger[0].dataset.id;
  	  				
	  	  		swal({
		  	  		  title: 'Are you sure?',
		  	  		  text: "You won't be able to revert this!",
		  	  		  type: 'warning',
		  	  		  showCancelButton: true,
		  	  		  cancelButtonColor: '#3085d6',
		  	  		  confirmButtonColor: '#d33',
		  	  		  toast: true,
		  	  		  backdrop: false,
		  	  		  confirmButtonText: 'Yes, delete it!'
		  	  		}).then((result) => {
		  	  		  if (result.value) {
		  	  			deletePlan(id);
		  	  		    $(this).fadeOut(1000);
		  	  			  swal({
			  	  			  title: 'Deleted!',
	  			  	  		  text: "Program plan has been deleted.",
	  			  	  		  type: 'success',
	  			  	  		  backdrop: false
		  	  			  })
		  	  		  }
		  	  		})
  	  			
  	  			
	  			}}
          }
      });
	
	$("#trainee_list").on("click", ".remove-plan", function(e){
		var id = $(this).closest("li").data("id");
  		swal({
  	  		  title: 'Are you sure?',
  	  		  text: "You won't be able to revert this!",
  	  		  type: 'warning',
  	  		  showCancelButton: true,
  	  		  cancelButtonColor: '#3085d6',
  	  		  confirmButtonColor: '#d33',
  	  		  target: "#planModal",
  	  		  backdrop: false,
  	  		  confirmButtonText: 'Remove trainee'
  	  		}).then((result) => {
  	  		  if (result.value) {
  	  			  $(this).closest("li").fadeOut(1000);
  	  			removeUserFromPlan(id);
  	  			  swal(
  	  		      'Remove!',
  	  		      'Trainee has been removed from the plan. ',
  	  		      'success'
  	  		    )
  	  		  }
  	  		})
		
  		
  		
	})
	
	function removeUserFromPlan(id){
		$.ajax({
  			url : "http://localhost:8080/api/user/plan/" + id,
  			type : "delete",
  			dataType : "json",
  			contentType : "application/json",
  			success : function(response) {
  			},
  			error : function(response) {
  				console.log(response);
  			}
  		})
	}
	
    function deletePlan(id){
    	  $.ajax({
  			url : "http://localhost:8080/api/plan/" + id,
  			type : "delete",
  			dataType : "json",
  			contentType : "application/json",
  			success : function(response) {
  			},
  			error : function(response) {
  				console.log(response);
  			}
  		})
      }  
      
	$('.select-trainees').select2({
		  dropdownParent: $('#planModal'),
		  minimumInputLength: 2,
		  placeholder: "Add trainees...",
		  ajax: {
		    url: 'http://localhost:8080/api/user/find/userplan',
		    data: function(params){
		    	var query = {
		    		name: params.term
		    	}
		    	return query;
		    },
		    processResults: function (data) {
		    	  return {
		    	    results: data
		    	  }
		    }
	
		  }
		});

	$.ajax({
			url : "http://localhost:8080/api/plans",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var plan_template = '<button type="button" class="btn btn-pill btn-info plans context-menu-one pb-2" data-id="'+ response[i].planID +'" style="width:200px">'
						+ response[i].name + '</button>';
					$("#planContent").append(plan_template);
				}
			}
	});
	
	$("#savePlan").on("click",function(event) {
		$.ajax({
			url : "http://localhost:8080/api/plan",
			data : JSON.stringify({
					"name" :  planName.val(),
					"trainees": $(".select-trainees").select2("val")
					}),
			type : "post",
			dataType : "json",
			contentType : "application/json",	
			success : function(response) {
				var plan_template = '<button type="button" class="btn btn-pill btn-info plans context-menu-one pb-2" data-id="'+ response.id +'" style="width:200px">'
				+ planName.val() + '</button>';
				$("#planContent").append(plan_template);
				$("#planModal").modal('hide');
				planName.val("");				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	
	$("div.col-3").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/plan/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				swal("success", "deleted", "success" );
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	$("#btnAddPlan").on("click", function(){
		$("#planModal .modal-title").text("Add program plan");
		$("#savePlan").show();
		$("#trainee_list_wrapper").hide();
		$("#updatePlan").prop("hidden", true);
	});

	$("#updatePlan").on("click", function() {
		$.ajax({
			url : "http://localhost:8080/api/plan/" + planId,
			data : JSON.stringify({
					"name" :  planName.val(),
					"trainees": $(".select-trainees").select2("val")
					}),
			type : "put",
			dataType : "text",
			contentType : "application/json",
			success: function(response){
				
				swal({
					title:"Update plan", 
					text: "Successfully updated plan", 
					type: "success",
					backdrop: false
				});
				
				$("#planModal").modal('hide');
				
				$.ajax({
				    type: 'GET',
				    url: 'http://localhost:8080/api/user/plan/' + plan_id
				}).then(function(response){
					users = [];
					for (var data in response){
						users.push(response[data].userPlanId);
					}
				});
			}
		});
	});
	
	$("#btnCreateProgramDetail").on("click",function(event){

		var formData = {
				"moduleId" : module_id,
				"planId" : plan_id,
				"userPlanIds": users,
				"instructor" : instructor.val(),
				"startDate" : startDate.val(),
				"endDate" : endDate.val()
		};
		$.ajax({
			url: "http://localhost:8080/api/plandetail",
			type: "post",
			dataType: "json",
			data: JSON.stringify(formData),
			contentType: "application/json",
			success: function(response){
				$("#createProgramPlan").modal("hide");
				getPlanDetailById(plan_id);
			},
			error: function(response){
				console.log(module_id);
				console.log(response);
			}
		})
	});
	
	
	function getPlanDetailById(id){
		$.ajax({
			url: 'http://localhost:8080/api/plan/' + id,
			contentType: 'application/json',
			success:function(response){
				if (response.length === 0){
					$("#detailTable tbody").html("<tr class='placeholder text-center'><td colspan='7'>No modules found...</td></tr>");
				} else {
					var data_template = [];
					for(var i=0;i<response.length;i++){
						
					var table_template = '<tr data-detail-id="' + response[i].detailId +'">'
					+'<td class="text-center">'
					+'<div class="avatar d-block">'
						+response[i].name.charAt(0)
						+'</div>'
						+'</td>'
				+'<td>'
				+'<div>'+response[i].name+'</div></td>'
				+'<td>'+response[i].description+'</td>'
				+'<td>'+response[i].instructor+'</td>'
				+'<td>'+ moment(response[i].startDate).format("MMMM DD, YYYY")+'</td>'
				+'<td>'+ moment(response[i].endDate).format("MMMM DD, YYYY")+'</td>'
				+'<td>'
				+'<div class="item-action dropdown">'
				
				+'<a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i class="fe fe-more-vertical"></i></a>'
				+'<div class="dropdown-menu dropdown-menu-right">'
				+'<a href="javascript:void(0)" class="dropdown-item edit" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>'
				+'<a href="javascript:void(0)" class="dropdown-item delete" data-id="'+response[i].detailId+'"><i class="dropdown-icon fe fe-trash"></i> Delete</a>'
				+'</div></div></td></tr>';
					data_template.push(table_template);
				
					}
					$("#detailTable tbody").html(data_template);
					
				}
				}

		});
	}
	
	$("body").on("click", ".plans", function(){
		$("#createProgramButton").attr("hidden", false);
		plan_id = $(this).data('id');
		$.ajax({
			    type: 'GET',
			    url: 'http://localhost:8080/api/user/plan/' + plan_id
			}).then(function(response){
				users = [];
				for (var data in response){
					users.push(response[data].userPlanId);
				}
			})
		getPlanDetailById(plan_id);

	});
	
	$("table tbody").on("click", ".delete", function(event){
		var id = $(this).closest("tr").data('detail-id');
		swal({
	  		  title: 'Are you sure?',
	  		  text: "You won't be able to revert this!",
	  		  type: 'warning',
	  		  showCancelButton: true,
	  		  cancelButtonColor: '#3085d6',
	  		  confirmButtonColor: '#d33',
	  		  toast: true,
	  		  backdrop: false,
	  		  confirmButtonText: 'Yes, delete it!'
	  		}).then((result) => {
	  		  if (result.value) {
	  			$(this).closest("tr").fadeOut(1000);
	  			$.ajax({
	  				url : "http://localhost:8080/api/plandetail/" + id,
	  				type : "delete",
	  				dataType : "json",
	  				contentType : "application/json",
	  				success : function(response) {
	  					 swal({
	  		  	  			  title: 'Deleted!',
	  			  	  		  text: response.message,
	  			  	  		  type: 'success',
	  			  	  		  backdrop: false
	  		  			  })
	  				},
	  				error : function(response) {
	  					console.log(response);
	  				}
	  			})
	  			 
	  		  }
	  		})

	});
	$("body").on("click", ".edit", function(event){
		
		
		var instructor = $(this).closest("tr").find("td:nth-child(4)").text();
		var startDate = $(this).closest("tr").find("td:nth-child(5)").text();
		var endDate = $(this).closest("tr").find("td:nth-child(6)").text();
		
		
		
		
		var startDateJS = $("<input type='text'  name='startDate' class='form-control startDate' value='"+ startDate +"'>").datepicker(startDateOpts).on("change", function() {
			endDateJS.datepicker("option", "minDate", datepickerParse(this))
		});
		
		var endDateJS = $("<input type='text' name='endDate' class='form-control endDate' value='"+ endDate +"'>").datepicker(endDateOpts).on("change", function() {
			startDateJS.datepicker("option", "maxDate", datepickerParse(this))
		});
		
		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		
		$(this).closest("tr").find("td:nth-child(4)").html("<input type='text' class='form-control' value='"+ instructor +"'>");
		$(this).closest("tr").find("td:nth-child(5)").html(startDateJS);
		$(this).closest("tr").find("td:nth-child(6)").html(endDateJS);
		$(this).closest("td").html("").append(btnSave);
	});
	
	

	$("body").on("click", "#btnSave", function(event){
		var id = $(this).closest("tr").data('detail-id');
		var instructor = $(this).closest("tr").find("td:nth-child(4) input").val();
		var startDate = $(this).closest("tr").find("td:nth-child(5) input").val();
		var endDate = $(this).closest("tr").find("td:nth-child(6) input").val();

		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		var dropdown_template =$("<div class='item-action dropdown'>" 
					+"<a href='javascript:void(0)' data-toggle='dropdown' class='icon'>"
					+"<i class='fe fe-more-vertical'></i></a><div class='dropdown-menu dropdown-menu-right'>"
					+"<a href='javascript:void(0)' class='dropdown-item edit'><i class='dropdown-icon fe fe-edit-2'></i> Edit </a><a href='javascript:void(0)' class='dropdown-item delete'><i class='dropdown-icon fe fe-trash-2'></i> Delete</a></div></div></td></tr>");

		$(this).closest("tr").find("td:nth-child(4)").html(instructor);
		$(this).closest("tr").find("td:nth-child(5)").html(startDate);
		$(this).closest("tr").find("td:nth-child(6)").html(endDate);
		$(this).closest("td").html("").append(dropdown_template);
		
		
		var setData = {
				instructor : instructor,
				startDate : moment(startDate, "MMMM DD, YYYY").format("YYYY-MM-DD"),
				endDate : moment(endDate, "MMMM DD, YYYY").format("YYYY-MM-DD")
		};
		$.ajax({
			url: "http://localhost:8080/api/plandetail/" + id,
			data: JSON.stringify(setData),
			type: "put",
			contentType: "application/json",
			dataType: "json",
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log(response);
			}
		});
	});
	
	
	var modules = $( ".module" ).autocomplete({
		source: function(request, response){
    		$.ajax({
                    url: "http://localhost:8080/api/module",
                    data: {
                    		name: request.term
                    },
                    dataType: "json",
                    success: function(data){
                          response ($.map(data, function(item){
                             return {
                            	 		id: item.id,
                        	 			label: item.name,
                        	 			value: item.name,
                        	 			description: item.description
                             		};
                          })); 
                    }
    		});
	  },
	  autoFocus: true,
	  minLength: 2,
	  change: function(event, ui){
		  var element = $(event.target);
          if (ui.item === null){
              element.val("");
          }
	  },
	  select: function (event, ui) {        
		  module_id = ui.item.id;
		  return true;
	  },
	  messages: {
		  noResults: function(count) {
			  $("#tags").attr("placeholder", "There were " + count + " matches");
		  },
	  }  
}).autocomplete( "instance" )._renderItem = function( ul, item ) {
          return $( "<li>" )
            .append( "<div>" + '<span data-id="' + item.id  + '" class="avatar avatar-' + colorize() + '">' + item.label.substring(0, 1) + '</span>' + "<strong class='result-icon'>" + " " +item.label + "</strong>" + "<br>" + item.description + "</div>" )
            .appendTo( ul );
        };
        
    $(".module").autocomplete("option", "appendTo", "#planDetailForm");
    
    $("#planModal").on("hidden.bs.modal", function(){
    	planName.val("");
    	$('.select-trainees').val('').trigger('change');
    });
      
    
    $("#createProgramPlan").on("hidden.bs.modal", function() {
    	$("#planDetailForm")[0].reset();
    });
	function datepickerParse(element){
		var date = $.datepicker.parseDate(dateFormat, element.value);
		return date;
	}
  
   
});
		



	function colorize()	{
		var colors = [
		       "blue",
		       "azure",
		       "indigo",
		       "purple",
		       "pink",
		       "red",
		       "orange",
		       "yellow",
		       "lime",
		       "green",
		       "teal",
		       "cyan",
		       "gray",
		       "gray-dark"
		];
		
		return colors[parseInt((Math.random() * colors.length) + 1)];
	}


   
