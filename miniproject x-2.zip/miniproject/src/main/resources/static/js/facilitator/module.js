$(function() {

	var title = $("input[name=name]");
	var desc = $("textarea[name=description]");

	var modules = function() {
		$.ajax({
			url : "http://localhost:8080/api/modules",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var card_template = '<div class="col-lg-6"><div class="card"><div class="card-status bg-purple"></div><div class="card-header">' +
								'<h3 class="card-title">'+ response[i].name + '</h3>' +
						'<div class="card-options"><a href="#" class="icon update" data-id="'+ response[i].id  +'"><span  class="fe fe-edit text-primary"></span></a><a href="#" class="icon delete" data-id="'+ response[i].id  +'"><span class="fe fe-trash text-danger"></span></a></div>' 
					 	
						+ '</div><div class="card-body">'
						+ response[i].description + '</div></div></div>';
				$("#moduleContent").append(card_template);
				}
			}
		});
	}

	
	modules();
	
	
	
	$("body").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().parent().parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/module/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	

	
	$("#saveModule").on("click",function(event) {

        event.preventDefault();
        
        var formData = {
               "name" : title.val(),
               "description" : desc.val()
        };

        $.ajax({
               url : "http://localhost:8080/api/module",
               data : JSON.stringify(formData),
               type : "post",
               dataType : "json",
               contentType : "application/json",
               success : function(response) {
                      var card_template = '<div class="col-lg-6"><div class="card"><div class="card-status bg-purple"></div><div class="card-header"><h3 class="card-title">'
                             + title.val()
                             + '</h3>'+ '<div class="card-options"><a href="#" class="icon update" data-id="'+ response.id  +'"><span  class="fe fe-edit text-primary"></span></a><a href="#" class="icon delete" data-id="'+ response.id  +'"><span class="fe fe-trash text-danger"></span></a></div>' 
                             +'</div><div class="card-body">'
                             + desc.val() + '</div></div></div>';
               $("#moduleContent").append(card_template);
               $("#moduleForm")[0].reset();
               swal(
       	  		      'Added!',
       	  		      'Module has been added. ',
       	  		      'success'
       	  		    )
                      
               },
               error : function(response) {
            	   var errors = response.responseJSON.errors;
					for (var field in errors){
						$("[name=" + field + "]").removeClass("is-valid").addClass("is-invalid").next().next().html(errors[field]);
					}
               }
        })
 

});


	$("body").on("click", ".update", function(event){
	
		var text = $(this).parent().parent().next().text();
		var title = $(this).parent().parent().find('h3').text();
		
		$(this).parent().parent().find('h3').html("<input type='text' class='form-control' value='" + title + "'>");
		$(this).parent().parent().next().html("<textarea class='form-control'>" + text + "</textarea>" );
		$(this).removeClass("update").addClass("save").find("span").removeClass("fe fe-edit").addClass("fe fe-save");
	});
	
	
	$("body").on("click", ".save", function(event){
		var id = $(this).data('id');
		var text = $(this).parent().parent().next().find("textarea").val();
		var title = $(this).parent().parent().find("input").val();

		$(this).parent().parent().find("h3").text(title);
		$(this).parent().parent().next().html(text);
		$(this).removeClass("save").addClass("update").find("span").removeClass("fe fe-save").addClass("fe fe-edit");
		
		var setData = {
				id : id,
				name: title,
				description : text
		};
		$.ajax({
			url: "http://localhost:8080/api/module/" + id,
			data: JSON.stringify(setData),
			type: "put",
			contentType: "application/json",
			dataType: "json",
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log(response);
			}
		});
	});
	
					
})
	

