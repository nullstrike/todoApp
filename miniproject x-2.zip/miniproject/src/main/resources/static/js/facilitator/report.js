 $(function() {
	   
	   var currentDate = moment().format('YYYY-MM-DD');
	   var empty_template = '<tr class="task_placeholder header">' +
		'<td>Nothing to show here...</td>'	+
			'</tr>';
	   var userId;
	   
	   
	   
        $('.select-trainees').select2({
   		  minimumInputLength: 2,
   		  placeholder: "Search trainees...",
   		  ajax: {
   		    url: 'http://localhost:8080/api/user/find',
   		    data: function(params){
   		    	var query = {
   		    		name: params.term
   		    	}
   		    	return query;
   		    },
   		    processResults: function (data) {
   		    	  return {
   		    	    results: data
   		    	  }
   		    }
   	
   		  }
   		}).on("select2:select", function(e) {
   			userId = $(this).select2('val');
   			
   		 $.ajax({
  		   
 			url : "http://localhost:8080/api/user/report/" + userId,
 			contentType : "application/json",
 			type : "get",
 			success : function(response) {
 				var tt = [];
 				tt = response;
 				
 				resetTable();
 				
 				enumerateLists(tt, currentDate);
 			}
        });
 		   
         });
        
        $('#dailyreportcalendar').fullCalendar({
        	selectable: true,
        	dayClick: function(date){
        		$.ajax({
       		   
     			url : "http://localhost:8080/api/user/report/" + userId,
     			contentType : "application/json",
     			type : "get",
     			success : function(response){
     				var tt = [];
     				tt=response;
     				
     				resetTable();
     				
     				enumerateLists(tt, date.format());
     				
     				}
     			});
        		
        	}
        });
        
        
        
        
        
        
        
        
        function enumerateLists(tt, date){
        	for (i=0; i<tt.length; i++){
			
				if(tt[i].date === date){
					
					switch(tt[i].type){
					case "Done": {
						if(tt[i].content)
							$("#view_completed_listf").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				
					case "Challenges":{
						if(tt[i].content)
						$("#view_challenge_listf").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				
					case "Todo": {
						if(tt[i].content)
						$("#view_todo_listf").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				}

				}
			}
        }
        

        function templateOfRows(task){
        	var template = '<tr class="tasks_lists" >' +
				'<td style="width:75%">' + task + '</td>' +
		   '</tr>';
        	
        	return template;
        }
        
        function resetTable(){
        	$("#view_completed_listf tbody, #view_challenge_listf tbody, #view_todo_listf tbody").each(function() {
	     			$(this).find("tr").remove();
	     			$(this).append(empty_template);
	     		});
        }
        
});
		

	 
  	     
	



