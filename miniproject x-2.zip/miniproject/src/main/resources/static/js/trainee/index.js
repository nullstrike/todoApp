$(function(){
	/*var title = $("input[name=planName]");
	var module_id, plan_id;
	var instructor = $("input[name=instructor]");
	var startDate = $("input[name=startDate]");
	var endDate = $("input[name=endDate]");
	var user_id = parseInt($("#user_id").text());
	 */
	var plan_id;
	var userId  = $("#user_id").text();
	console.log(userId);
	$.ajax({
		url : "http://localhost:8080/api/plans/" + userId,
		contentType : "application/json",
		type : "get"
	}).done(function(response){
		$.ajax({
		url: "http://localhost:8080/api/plan/" + response,
		contentType: 'application/json',
		type: 'get',
		success: function(response){
						for(var i = 0 ; i < response.length; i++){
			var card_template = 
			'<div class="col-6 col-sm-4 col-lg-4 mb-6" >' +				
				'<div class="card">' +
					'<div class="card-body p-4 text-center">' +
								'<div class="text-right text-red">'+
                      				'<span class="badge badge-success">Completed</span>'+
                    			 '</div>'+
						' <div class="h1 mb-4" name="moduleName">' +
								response[i].name +
						'</div>' +
							'<p class="text-muted mb-4">' +
								response[i].description +
							'</p>' +
						'</div>' +
						'<div class="card-footer" >' +
							'<cite>Instructor : ' +
								response[i].instructor +
							'</cite></br>' +
							'<cite>Start Date : ' + 
								response[i].startDate +
							'</cite></br>' +
							'<cite>End Date : ' +
								response[i].endDate +
							'</cite>' +
						'</div>' +
					'</div>' +
				'</div>'+
			'</div>';
								
			$("#indexContent").append(card_template);
		}
		}
		
		
		});
	});	
var index = function() {
	
	
	
}/*
index();*/


	
	

	
	
	
	
});
	
