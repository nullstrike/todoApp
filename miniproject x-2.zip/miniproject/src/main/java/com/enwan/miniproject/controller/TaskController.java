package com.enwan.miniproject.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.CreateTaskReportDto;
import com.enwan.miniproject.model.Task;
import com.enwan.miniproject.service.TraineeService;

@RestController
@RequestMapping("/api/report")
public class TaskController {
	
	private final TraineeService traineeService;
	
	@Autowired
	public TaskController(TraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@PostMapping
	public Task addReport(@Valid @RequestBody CreateTaskReportDto taskReportDto) {
		Task task = new Task();
		task.setContent(taskReportDto.getText());
		task.setDate(new Date());
		task.setType(taskReportDto.getType());
		return traineeService.saveTask(task);
	}
}
