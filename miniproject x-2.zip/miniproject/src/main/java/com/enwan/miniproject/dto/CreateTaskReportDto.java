package com.enwan.miniproject.dto;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class CreateTaskReportDto {

	private Integer userId;
	
	private String text;
	
	private String type;



	
	
}
