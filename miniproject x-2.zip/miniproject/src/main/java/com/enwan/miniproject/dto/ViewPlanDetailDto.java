package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewPlanDetailDto {
	
/*    private Integer detailId;
    
    private Integer planId;*/
    
    private Integer detailId;
    
    private String name;
    
    private String description;
    
    private String instructor;
    
    private Date startDate;
    
    private Date endDate;

    
    
}
