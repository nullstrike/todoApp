package com.enwan.miniproject.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserTaskDto {
	
	private Integer userId;
	
	private String date;

}
