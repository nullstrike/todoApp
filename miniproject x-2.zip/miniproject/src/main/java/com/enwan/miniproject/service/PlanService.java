package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.PlanDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.model.UserPlan;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.UserPlanRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class PlanService implements IPlanService {


	private final PlanRepository planRepository;

	private final UserRepository userRepository;
	
	private final UserPlanRepository userPlanRepository;
	
	
	@Autowired
	public PlanService(PlanRepository planRepository, UserRepository userRepository,
			UserPlanRepository userPlanRepository) {
		super();
		this.planRepository = planRepository;
		this.userRepository = userRepository;
		this.userPlanRepository = userPlanRepository;
	}

	@Override
	public List<ViewPlanDto> getAllPlans() {
		return planRepository.findAllPlans();
	}

	

	@Override
	public Plan createPlan(PlanDto createPlan) {
		Plan plan = new Plan();
		plan.setName(createPlan.getName());
		Plan createdPlan = planRepository.save(plan);
		
		for (int i = 0; i < createPlan.getTrainees().size(); i ++) {
			UserPlan userPlan = new UserPlan();
			User user = userRepository.findById(createPlan.getTrainees().get(i)).get();
			userPlan.setPlan(createdPlan);
			userPlan.setUser(user);
			userPlanRepository.save(userPlan);
		}
		
		return createdPlan;
	}

	@Override
	public void deletePlanById(Integer id) {
		Plan plan = planRepository.findById(id).get();
		planRepository.delete(plan);
	}

	@Override
	public void updatePlan(Integer id, PlanDto updatePlan) {
		Plan plan = planRepository.findById(id).get();
		plan.setName(updatePlan.getName());
		for (int i = 0; i < updatePlan.getTrainees().size(); i ++) {
			UserPlan userPlan = new UserPlan();
			User user = userRepository.findById(updatePlan.getTrainees().get(i)).get();
			userPlan.setPlan(plan);
			userPlan.setUser(user);
			userPlanRepository.save(userPlan);
		}
		planRepository.save(plan);
		
	}

	@Override
	public List<ViewPlanDetailDto> getPlanById(Integer planId) {
		List<ViewPlanDetailDto> planDetail = planRepository.findAllBy(planId);
		return planDetail;
	}

	@Override
	public List<UserPlan> findPlanById(Integer UserId) {
		List<UserPlan> planDetail = userPlanRepository.findAllBy(UserId);
		return planDetail;
	}

}
