package com.enwan.miniproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.service.IPlanService;

@RestController
@RequestMapping("/api/test")
public class TestController {

	private IPlanService planService;

	@Autowired
	public TestController(IPlanService planService) {
		this.planService = planService;
	}
	
	@PostMapping
	public void delete() {
		planService.deletePlanById(1);
	}
	
}
