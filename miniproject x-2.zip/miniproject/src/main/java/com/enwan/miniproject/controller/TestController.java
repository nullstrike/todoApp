package com.enwan.miniproject.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.NewTraineesDto;
import com.enwan.miniproject.repository.UserPlanRepository;
import com.enwan.miniproject.repository.UserStatusRepository;
import com.enwan.miniproject.service.IPlanService;

@RestController
@RequestMapping("/api/test")
public class TestController {

	private IPlanService planService;
	
	
	@Autowired
	private UserPlanRepository userPlanRepository;
	
	@Autowired
	private UserStatusRepository userStatusRepository;

	@Autowired
	public TestController(IPlanService planService) {
		this.planService = planService;
	}
	
	@PostMapping
	public void delete() {
		planService.deletePlanById(1);
	}
	
	@GetMapping
	public ResponseEntity<?> gets(){
		final int id = 1;
		List<NewTraineesDto> newTrainees = userPlanRepository.getNewlyAddedTrainees(id);

		List<NewTraineesDto> newTraineesModules = userStatusRepository.getModulesNewTraineesPartial(id);
		
		Map<String, Object> resultSets = new LinkedHashMap<>();
		resultSets.put("New Trainees", newTrainees);
		resultSets.put("newModules", newTraineesModules);
		resultSets.put("ID2", newTraineesModules.get(0).getId());
		resultSets.put("ID", newTraineesModules.get(1).getId());
		for(int i =0; i < newTraineesModules.size(); i++) {
			System.out.println(newTraineesModules.get(i).getId());
		}
		return ResponseEntity.ok(resultSets);
	}
	
}
