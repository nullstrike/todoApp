package com.enwan.miniproject.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "userplan")
public class UserPlan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserPlanId")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "PlanId", nullable = false)
	private Plan plan;
	
	@ManyToOne
	@JoinColumn(name = "UserId", nullable = false)
	private User user;
	
	@OneToMany(mappedBy = "userPlan", cascade = CascadeType.ALL)
	@JsonIgnore
	private Set<UserStatus> userStatus;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

}
