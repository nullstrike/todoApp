package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.repository.ModuleRepository;
import com.enwan.miniproject.repository.PlanDetailRepository;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class PlanDetailService implements IPlanDetailService {


	private final PlanDetailRepository planDetailRepository;
	
	private final ModuleRepository moduleRepository;

	private final PlanRepository planRepository;
	

	
	@Autowired
	public PlanDetailService(PlanDetailRepository planDetailRepository, ModuleRepository moduleRepository,
			PlanRepository planRepository) {
		this.planDetailRepository = planDetailRepository;
		this.moduleRepository = moduleRepository;
		this.planRepository = planRepository;
	}

	@Override
	public void createPlanDetail(CreatePlanDetailDto createPlanDetail) {
		PlanDetail planDetail = new PlanDetail();
		
		Module module = moduleRepository.findById(createPlanDetail.getModuleId()).get();
		Plan plan = planRepository.findById(createPlanDetail.getPlanId()).orElseThrow(() -> new RuntimeException("No plan found"));

		
		planDetail.setEndDate(createPlanDetail.getEndDate());
		planDetail.setInstructor(createPlanDetail.getInstructor());
		planDetail.setStartDate(createPlanDetail.getStartDate());
		planDetail.setModule(module);
		
		planDetailRepository.save(planDetail);
	}

	@Override
	public void updatePlanDetail(Integer planId, UpdatePlanDetailDto updatePlanDetail) {
		PlanDetail planDetail = planDetailRepository.findById(planId).get();
		planDetail.setEndDate(updatePlanDetail.getEndDate());
		planDetail.setInstructor(updatePlanDetail.getInstructor());
		planDetail.setStartDate(updatePlanDetail.getStartDate());
				
		planDetailRepository.save(planDetail);

	}

	@Override
	public void deletePlanDetailById(Integer id) {
		PlanDetail planDetail = planDetailRepository.findById(id).get();
		planDetailRepository.delete(planDetail);
	}

/*	@Override
	public List<ViewPlanDetailDto> findAllPlan(Integer plan_id) {
		return planRepository.findAllBy(plan_id);
	}*/

	

}
