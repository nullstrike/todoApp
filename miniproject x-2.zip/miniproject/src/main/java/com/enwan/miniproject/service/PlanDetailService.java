package com.enwan.miniproject.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.model.UserPlan;
import com.enwan.miniproject.model.UserStatus;
import com.enwan.miniproject.repository.ModuleRepository;
import com.enwan.miniproject.repository.PlanDetailRepository;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.UserPlanRepository;
import com.enwan.miniproject.repository.UserStatusRepository;


@Service
public class PlanDetailService implements IPlanDetailService {


	private final PlanDetailRepository planDetailRepository;
	
	private final ModuleRepository moduleRepository;

	private final UserPlanRepository userPlanRepository;
	
	private final UserStatusRepository userStatusRepository;
	
	private final PlanRepository planRepository;
	
	private static final int DEFAULT_STATUS = 0;
	
	@Autowired
	public PlanDetailService(PlanDetailRepository planDetailRepository, ModuleRepository moduleRepository,
			UserPlanRepository userPlanRepository, UserStatusRepository userStatusRepository,
			PlanRepository planRepository) {
		this.planDetailRepository = planDetailRepository;
		this.moduleRepository = moduleRepository;
		this.userPlanRepository = userPlanRepository;
		this.userStatusRepository = userStatusRepository;
		this.planRepository = planRepository;
	}

	@Override
	public void createPlanDetail(CreatePlanDetailDto createPlanDetail) {
		PlanDetail planDetail = new PlanDetail();
		
		Plan plan = planRepository.findById(createPlanDetail.getPlanId()).get();
		Module module = moduleRepository.findById(createPlanDetail.getModuleId()).get();
		planDetail.setEndDate(createPlanDetail.getEndDate());
		planDetail.setInstructor(createPlanDetail.getInstructor());
		planDetail.setStartDate(createPlanDetail.getStartDate());
		planDetail.setModule(module);
		planDetail.setPlan(plan);
		
		PlanDetail savedPlanDetail = planDetailRepository.save(planDetail);
		
		for(int i = 0; i < createPlanDetail.getUserPlanIds().size(); i++) {
			UserPlan userPlan = userPlanRepository.findById(createPlanDetail.getUserPlanIds().get(i)).get();
			UserStatus userStatus = new UserStatus();
			userStatus.setPlanDetail(savedPlanDetail);
			userStatus.setUserPlan(userPlan);
			userStatus.setStatus(DEFAULT_STATUS);
			userStatusRepository.save(userStatus);
		}

	}

	@Override
	public void updatePlanDetail(Integer planId, UpdatePlanDetailDto updatePlanDetail) {
		PlanDetail planDetail = planDetailRepository.findById(planId).get();
		planDetail.setEndDate(updatePlanDetail.getEndDate());
		planDetail.setInstructor(updatePlanDetail.getInstructor());
		planDetail.setStartDate(updatePlanDetail.getStartDate());
				
		planDetailRepository.save(planDetail);

	}

	@Override
	public void deletePlanDetailById(Integer id) {
		PlanDetail planDetail = planDetailRepository.findById(id).get();
		planDetailRepository.delete(planDetail);
	}

}
