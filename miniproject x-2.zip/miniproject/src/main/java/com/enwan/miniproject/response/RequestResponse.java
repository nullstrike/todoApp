package com.enwan.miniproject.response;

import lombok.Data;

@Data
public class RequestResponse {
	
	private Boolean success;
	private String message;
	private Integer id;
	
	public RequestResponse(Boolean success, String message) {
		this.success = success;
		this.message = message;
	}

	public RequestResponse(Boolean success, String message, Integer id) {
		this.success = success;
		this.message = message;
		this.id = id;
	}
	
	
	
}
