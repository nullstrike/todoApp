package com.enwan.miniproject.service;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;

public interface IPlanDetailService {
	
	void createPlanDetail(CreatePlanDetailDto createPlanDetail);
	
	void updatePlanDetail(Integer planId,UpdatePlanDetailDto updatePlanDetail);

	void deletePlanDetailById(Integer planId);
	
}
