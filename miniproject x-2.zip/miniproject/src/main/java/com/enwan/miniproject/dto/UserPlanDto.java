package com.enwan.miniproject.dto;

import lombok.Data;

@Data
public class UserPlanDto {
	
	private Integer id;
	
	private String text;

	private Integer userId;
	
	public UserPlanDto(Integer id, String text) {
		this.id = id;
		this.text = text;
	}

	public UserPlanDto(Integer id, String text, Integer userId) {
		this.id = id;
		this.text = text;
		this.userId = userId;
	}
	
	
	
	
}
