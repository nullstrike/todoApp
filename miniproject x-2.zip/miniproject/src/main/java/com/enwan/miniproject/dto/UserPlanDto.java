package com.enwan.miniproject.dto;

import lombok.Data;

@Data
public class UserPlanDto {
	
	private Integer id;
	
	private String text;

	private Integer userPlanId;
	
	public UserPlanDto(Integer id, String text) {
		this.id = id;
		this.text = text;
	}

	public UserPlanDto(Integer id, String text, Integer userPlanId) {
		this.id = id;
		this.text = text;
		this.userPlanId = userPlanId;
	}

	
	
	
	
	
}
