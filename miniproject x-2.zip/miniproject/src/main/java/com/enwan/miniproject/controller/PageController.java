package com.enwan.miniproject.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@RestController
@RequestMapping("/")
public class PageController {
	
	@GetMapping({"", "login"})
	public ModelAndView index() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			for (GrantedAuthority authority: auth.getAuthorities()) {
				if (authority.getAuthority().equals("ROLE_ADMIN")) {
					return new ModelAndView(new RedirectView("/admin"));
				} else if (authority.getAuthority().equals("ROLE_FACILITATOR")) {
					return new ModelAndView(new RedirectView("/facilitator"));
				} else {
					return new ModelAndView(new RedirectView("/trainee"));
				}
			}
		}
		return pageLoader("main/login");
	}
	
	@GetMapping("admin")
	public ModelAndView adminIndex() {
		return pageLoader("admin/index", "admin");
	}
	
	@GetMapping({"facilitator", "facilitator/plandetail"})
	public ModelAndView facilitatorIndex() {
	 return	pageLoader("facilitator/index", "facilitator_plan");
	}
	
	@GetMapping("/facilitator/reports")
	public ModelAndView dailyReport() {
		return pageLoader("facilitator/report", "facilitator_report");
	}
	
	@GetMapping("facilitator/modules")
	public ModelAndView moduleIndex() {
		return pageLoader("facilitator/modules", "facilitator_modules");
	}
	
	@GetMapping("trainee")
	public ModelAndView traineeIndex() {
		return pageLoader("trainee/index", "default_trainee");
	}
	
	@GetMapping("trainee/report")
	public ModelAndView dailyReportIndex() {
		return pageLoader("trainee/report", "trainee");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public ModelAndView pageLoader(String viewname) {
		ModelAndView page = new ModelAndView();
		page.setViewName(viewname);
		return page;
	}
	public ModelAndView pageLoader(String content, String section) {
		ModelAndView page = new ModelAndView();
		page.addObject("content", content);
		page.addObject("section", section);
		page.setViewName("layouts/template");
		return page;
	}
	
}
