package com.enwan.miniproject.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "plandetail")
public class PlanDetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DetailID")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "ModuleID", nullable = false)
	private Module module;
	
	@Column(name = "StartDate", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name = "EndDate", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name = "Instructor", nullable = false)
	private String instructor;
	
	@OneToMany(mappedBy = "planDetail", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@JsonIgnore
	private Set<UserStatus> userStatus;
	
}
