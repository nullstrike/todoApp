package com.enwan.miniproject.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class CreatePlanDetailDto {

	private List<Integer> userPlanIds;
	
	private Integer planId;
	
	private Integer moduleId;

	private String instructor;
	
	private Date startDate;
	
	private Date endDate;

	public CreatePlanDetailDto() {
	}
	
	public CreatePlanDetailDto(List<Integer> userPlanId, Integer moduleId, String instructor, Date startDate,
			Date endDate) {
		this.userPlanIds = userPlanId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public CreatePlanDetailDto(Integer planId, Integer moduleId, String instructor, Date startDate, Date endDate) {
		this.planId = planId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	

	
	
	
	
}
