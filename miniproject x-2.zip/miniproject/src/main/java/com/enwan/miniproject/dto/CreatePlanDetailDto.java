package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.Data;

@Data
public class CreatePlanDetailDto {

	private Integer planId;
	
	private Integer moduleId;

	private String instructor;
	
	private Date startDate;
	
	private Date endDate;
	
	
	public CreatePlanDetailDto(Integer planId, Integer moduleId, String instructor, Date startDate, Date endDate) {
		this.planId = planId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	
	
	
	
}
