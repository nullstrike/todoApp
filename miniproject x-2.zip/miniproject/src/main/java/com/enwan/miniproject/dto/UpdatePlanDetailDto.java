package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UpdatePlanDetailDto {


    private String instructor;
    
    private Date startDate;
    
    private Date endDate;

	public UpdatePlanDetailDto(String instructor, Date startDate, Date endDate) {
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

    
    
    
}
