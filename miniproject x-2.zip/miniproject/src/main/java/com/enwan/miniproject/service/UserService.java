package com.enwan.miniproject.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.ChangePasswordDto;
import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.dto.UserPlanDto;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.Role;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.model.UserPlan;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.RoleRepository;
import com.enwan.miniproject.repository.UserPlanRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class UserService implements IUserService {
	
	private final UserRepository userRepository;

	private final RoleRepository roleRepository;

	private final BCryptPasswordEncoder passwordEncoder;
	
	private final PlanRepository planRepository;
	
	private UserPlanRepository userPlanRepository;
	
	private static final String DEFAULT_PASSWORD = "Welcome18";
	
	private static final String DEFAULT_ROLE = "ROLE_TRAINEE";

    @Autowired
	public UserService(UserRepository userRepository, RoleRepository roleRepository,
			BCryptPasswordEncoder passwordEncoder, PlanRepository planRepository,
			UserPlanRepository userPlanRepository) {
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		this.passwordEncoder = passwordEncoder;
		this.planRepository = planRepository;
		this.userPlanRepository = userPlanRepository;
	}


	@Override
	public User createUser(CreateUserDto createUserDto) {
		User user = new User();
		Role userRole = roleRepository.findById(createUserDto.getRole()).orElseThrow(() -> new RuntimeException("No user role found."));
		user.setFirstName(createUserDto.getFirstName());
		user.setMiddleName(createUserDto.getMiddleName());
		user.setLastName(createUserDto.getLastName());
		user.setUsername(createUserDto.getUsername());
		user.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
		user.setRole(userRole);
		return userRepository.save(user);
	}


	@Override
	public User changePassword(ChangePasswordDto changePasswordDto) {
		User user = userRepository.findByUsername(changePasswordDto.getUsername());
		user.setPassword(passwordEncoder.encode(changePasswordDto.getNewPassword()));
		return userRepository.save(user);
	}

	@Override
	public Boolean checkUsernameExist(String username) {
		return userRepository.existsByUsername(username);
	}

	@Override
	public List<UserDetailDto> getUsers() {
		return userRepository.userDetailView("ROLE_ADMIN");
	}

	@Override
	public String getNames(String username) {
		NamesOnlyDto name =  userRepository.NamesView(username);
		if (name.getFirstName().equals("N/A")) {
			return "";
		} else {
			return name.getFirstName() + " " + name.getLastName();
		}
	}

	@Override
	public Boolean checkPasswordMatches(String username,String raw) {
		User user = userRepository.findByUsername(username);
		return passwordEncoder.matches(raw, user.getPassword());
	}

	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public void resetPassword(Integer id) {
		User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("No user found."));
		user.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
	    userRepository.save(user);
	}


	@Override
	public List<UserPlanDto> getTraineesByName(String name) {
		Role trainee = roleRepository.findByRoleName(DEFAULT_ROLE);
		return userRepository.filterTraineesByName(trainee, name);
	}


	@Override
	public List<UserPlanDto> getExistingTraineesByPlan(Integer planId) {
		Plan currentPlan = planRepository.findById(planId).get();
		return userRepository.filterTraineesByPlan(currentPlan);
	}


	@Override
	public void deleteByUserPlan(Integer userPlanId) {
		UserPlan userPlan = userPlanRepository.findById(userPlanId).get();
		userPlanRepository.delete(userPlan);
	}


	@Override
	public User getUserbyId(Integer id) {
		User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("No user found. "));
		return user;
	}




		


}
