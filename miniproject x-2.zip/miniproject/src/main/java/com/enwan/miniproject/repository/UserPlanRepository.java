package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.ViewUserPlanDto;
import com.enwan.miniproject.model.UserPlan;

@Repository
public interface UserPlanRepository extends JpaRepository<UserPlan, Integer> {
	@Query("select (b.plan.id) from UserPlan b join b.user a on a.id = :UserId")
	List<UserPlan> findAllBy(@Param("UserId") Integer UserId);
	

	//List<ViewUserPlanDto> getAllId(@Param("PlanId") Integer planId);
}
