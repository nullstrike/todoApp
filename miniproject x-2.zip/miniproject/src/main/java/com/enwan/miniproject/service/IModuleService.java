package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.ModuleDto;
import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.model.Module;

public interface IModuleService {
	

	Module createModule(ModuleDto moduleDto);
	
	void updateModule (Integer id, ModuleDto moduleDto);

	void deleteModuleById(Integer id);
	
	List<ViewModuleDto> findAllModule();
	
	List<ViewModuleDto> findModuleByName(String name);

}
