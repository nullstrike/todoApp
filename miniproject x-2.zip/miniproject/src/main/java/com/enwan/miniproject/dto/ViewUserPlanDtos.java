package com.enwan.miniproject.dto;

import lombok.EqualsAndHashCode;

@EqualsAndHashCode
public class ViewUserPlanDtos {
	
	private Integer id;

	public ViewUserPlanDtos(Integer id) {
		this.id = id;
	}

	public ViewUserPlanDtos() { }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
