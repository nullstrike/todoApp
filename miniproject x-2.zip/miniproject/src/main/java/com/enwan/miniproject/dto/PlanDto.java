package com.enwan.miniproject.dto;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PlanDto {
	
	private String name;

	private List<Integer> trainees;

	public PlanDto(String name, List<Integer> trainees) {
		super();
		this.name = name;
		this.trainees = trainees;
	}

	public PlanDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
	
	
	
	
}
