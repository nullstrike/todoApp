package com.enwan.miniproject.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.enwan.miniproject.dto.ModuleDto;
import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.IModuleService;

@RestController
@RequestMapping("/api")
public class ModuleController {
	
	private final IModuleService moduleService;

	@Autowired
	public ModuleController(IModuleService moduleService) {
		this.moduleService = moduleService;
	}
	
	@GetMapping("/modules")
	public ResponseEntity<?> getAllModules(){
		List<ViewModuleDto> modules = moduleService.findAllModule();
		return new ResponseEntity<>(modules, HttpStatus.OK);
	}
	
	@GetMapping("/module")
	public ResponseEntity<?> getModuleByName(@RequestParam("name") String moduleName){
		List<ViewModuleDto> module = moduleService.findModuleByName(moduleName);
		return new ResponseEntity<>(module, HttpStatus.OK);
	}
	
	
	@PostMapping("/module")
	public ResponseEntity<?> createModule(@Valid @RequestBody ModuleDto moduleDto){
		moduleService.createModule(moduleDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created module"), HttpStatus.OK);
	}
	
	@RequestMapping(value ="/module/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateModule(@PathVariable("id") Integer id,@RequestBody ModuleDto moduleDto){
		
		moduleService.updateModule(id, moduleDto);
		
		return new ResponseEntity<>(new RequestResponse(true, "Successfully updated module."), HttpStatus.OK);
		
	}
	
	@DeleteMapping("/module/{id}")
	public ResponseEntity<?> deleteModule(@PathVariable("id") Integer moduleId){
		moduleService.deleteModuleById(moduleId);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully deleted module"), HttpStatus.OK);
	}
	

	
	
	
}
