package com.enwan.miniproject.service;



import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.UserTaskDto;
import com.enwan.miniproject.model.Task;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.repository.TaskRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class TraineeService {

	private final TaskRepository taskRepo;

	private final UserRepository userRepository;
	
	@Autowired
	public TraineeService(TaskRepository taskRepo, UserRepository userRepository) {
		this.taskRepo = taskRepo;
		this.userRepository = userRepository;
	}

	public Task saveTask(Task task) {
		return taskRepo.save(task);
	}

	public User getUser(@Valid UserTaskDto userTaskDto) {
		return userRepository.findById(userTaskDto.getUserId()).orElseThrow(() -> new RuntimeException("No user found."));
	}
	
	public List<Task> getTaskByUser (User user){
		return taskRepo.getTaskByUser(user);
	}
	
}
