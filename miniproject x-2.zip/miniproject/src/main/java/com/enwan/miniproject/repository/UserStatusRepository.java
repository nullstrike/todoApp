package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.NewTraineesDto;
import com.enwan.miniproject.model.UserStatus;

@Repository
public interface UserStatusRepository extends JpaRepository<UserStatus, Integer> {
	
	@Query("SELECT new com.enwan.miniproject.dto.NewTraineesDto (a.planDetail.id) from UserStatus a join a.userPlan b where b.plan.id = :planId ")
	List<NewTraineesDto> getModulesNewTrainees(@Param("planId") Integer plan_id);
	
	@Query("SELECT new com.enwan.miniproject.dto.NewTraineesDto (a.id) from PlanDetail a join a.plan b where b.id = :plan_id")
	List<NewTraineesDto> getModulesNewTraineesPartial(@Param("plan_id") Integer plan_id);
}
