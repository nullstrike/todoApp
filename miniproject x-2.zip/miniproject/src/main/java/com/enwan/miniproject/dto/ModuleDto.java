package com.enwan.miniproject.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ModuleDto {
	
	@Size(min = 3, max = 40, message = "name must be between 3 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
    private String name;
	@NotNull(message = "Current description field should not be null")
	@NotEmpty(message = "Current description field should not be empty")
    private String description;
	public ModuleDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ModuleDto( String name, String description) {
		super();
		
		this.name = name;
		this.description = description;
	}
	
}
