package com.enwan.miniproject.constraint;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.enwan.miniproject.dto.ChangePasswordDto;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object>  {

    @Override
    public void initialize(PasswordMatches constraintAnnotation) {}
    
    @Override
    public boolean isValid(Object obj, ConstraintValidatorContext context){   
        ChangePasswordDto user = (ChangePasswordDto) obj;
        return user.getNewPassword().equals(user.getConfirmPassword());    
    }   
	
}
