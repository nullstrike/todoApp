$(document).ready(function(){
	var title = $("input[name=planName]");
	var module_id, plan_id;
	var instructor = $("input[name=instructor]");
	var startDate = $("input[name=startDate]");
	var endDate = $("input[name=endDate]");
	
	$('input[name=startDate], input[name=endDate]').datepicker({
		format : "yyyy-dd-mm"
	});

	$.ajax({
			url : "http://localhost:8080/api/plans",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var plan_template = '<div class="btn-group pl-4 pb-2"><button type="button" class="btn btn-blue plans" data-id="'+ response[i].id +'" style="width:150px">'
						+ response[i].name + '</button>'+ '<button type="button" class="btn btn-danger icon delete" data-id="'+ response[i].id +'"><span class="fe fe-trash text-white"></span></button>'
					 	+'</div>';
					$("#planContent").append(plan_template);
				}
			}
	});

	$("#savePlan").on("click",function(event) {
		$.ajax({
			url : "http://localhost:8080/api/plan/createPlan",
			data : JSON.stringify({"name" :  title.val()),
			type : "post",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				var plan_template = '<div class="btn-group pl-4 pb-2"><button type="button" class="btn btn-blue" data-id="'+ response.id +'" style="width:150px">'
					+ title.val() + '</button>'+ '<button type="button" class="btn btn-danger icon delete" data-id="' + response.id + '"><span class="fe fe-trash text-white"></span></button>'
				 	+'</div>';

				$("#planContent").append(plan_template);
				$("#planModal").modal('hide');
				title.val("");				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	
	$("div.col-3").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/plan/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				swal("success", "deleted", "success" );
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	$("#btnRegister").on("click",function(event){
		console.log(module_id);
		var formData = {
				"moduleId" : module_id,
				"planId": plan_id,
				"instructor" : instructor.val(),
				"startDate" : startDate.val(),
				"endDate" : endDate.val()
		};
		$.ajax({
			url: "http://localhost:8080/api/planDetail/createPlanDetail",
			type: "post",
			dataType: "json",
			data: JSON.stringify(formData),
			contentType: "application/json",
			success: function(response){
				
				console.log(module_id);
				$("#createProgramPlan").modal("hide");
				
			},
			error: function(response){
				console.log(module_id);
				console.log(response);
			}
		})
	});
	var plan = function() {
		$.ajax({
			url : "http://localhost:8080/api/planDetail/createPlanDetail",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var table_template = '<td class="text-center"><div class="avatar d-block">' 
										 +response[i].name.charAt(0)+'</td><td>'+response[i].name+'</td><td>'
										 +response[i].description+'</td><td>'
										 +response[i].instructor+'</td><td>'
										 +response[i].startDate+'</td><td>'
										 +response[i].endDate+'</td><td class="text-center"><div class="item-action dropdown"><a href="javascript:void(0)" data-toggle="dropdown" class="icon">'
										 +'<i class="fe fe-more-vertical"></i></a><div class="dropdown-menu dropdown-menu-right">'
										 +'<div class="dropdown-menu dropdown-menu-right">'
										 +'<a href="javascript:void(0)" class="dropdown-item" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'"><i class="dropdown-icon fe fe-edit-2"></i> Edit</a>'
										 +'<a href="javascript:void(0)" class="dropdown-item" data-id="'+response[i].detailId+'"><i class="dropdown-icon fe fe-trash"></i> Delete</a>'
										 +'</div></div></td></tr>';
				$("#detailTable").append(table_template);
				}
			}
		});
	} 
	$("body").on("click", ".plans", function(){
		$("#createProgramButton").attr("hidden", false);
		plan_id = $(this).data('id');
		$.ajax({
			url: 'http://localhost:8080/api/plan/' + plan_id,
			contentType: 'application/json',
			success:function(response){
				if (response.length === 0){
					$("#detailTable tbody").html("<tr class='placeholder text-center'><td colspan='7'>No modules found...</td></tr>");
				} else {
					var data_template = [];
					for(var i=0;i<response.length;i++){
						
					var table_template = '<tr data-detail-id="' + response[i].detailId +'" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'">'
					+'<td class="text-center">'
					+'<div class="avatar d-block">'
						+response[i].name.charAt(0)
						+'</div>'
						+'</td>'
				+'<td>'
				+'<div>'+response[i].name+'</div></td>'
				+'<td>'+response[i].description+'</td>'
				+'<td>'+response[i].instructor+'</td>'
				+'<td>'+response[i].startDate+'</td>'
				+'<td>'+response[i].endDate+'</td>'
				+'<td>'
				+'<div class="item-action dropdown">'
				
				+'<a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i class="fe fe-more-vertical"></i></a>'
				+'<div class="dropdown-menu dropdown-menu-right">'
				+'<a href="javascript:void(0)" class="dropdown-item edit" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>'
				+'<a href="javascript:void(0)" class="dropdown-item delete" data-id="'+response[i].detailId+'"><i class="dropdown-icon fe fe-message-square"></i> Delete</a>'
				+'</div></div></td></tr>';
					data_template.push(table_template);
				
					}
					$("#detailTable tbody").html(data_template);
					
				}
				}

		});
	});
	$("table tbody").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().parent().parent().parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/planDetail/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	$("body").on("click", ".edit", function(event){
		
		var instructor = $(this).parent().parent().parent().prev().prev().prev().text();
		var startDate = $(this).parent().parent().parent().prev().prev().text();
		var endDate = $(this).parent().parent().parent().prev().text();
		
		
		$(this).parent().parent().parent().prev().prev().prev().html("<input type='text' class='form-control' value='"+ instructor +"'>");
		$('input[name=startDate]').datepicker({
			format : "yyyy-dd-mm"
		});
		
		var endDateJS = $("<input type='text' name='endDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000'  value='"+ endDate +"'>").datepicker({format : "yyyy-dd-mm"});
		var startDateJS = $("<input type='text'  name='startDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000' value='"+ startDate +"'>").datepicker({format: "yyyy-dd-mm"});
		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		
		$(this).parent().parent().parent().prev().prev().html(startDateJS);
		$(this).parent().parent().parent().prev().html(endDateJS);
		$(this).parent().parent().html("").append(btnSave);
	});
	
	
	$("body").on("click", "#btnSave", function(event){
		var id = $(this).parent().parent().parent().data('id');
		var instructor = $(this).parent().parent().parent().prev().prev().prev().find("input").val();
		var startDate = $(this).parent().parent().parent().prev().prev().find("input").val();
		var endDate = $(this).parent().parent().parent().prev().find("input").val();
		var endDateJS = $("<input type='text' name='endDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000'  value='"+ endDate +"'>").datepicker({format : "yyyy-dd-mm"});
		var startDateJS = $("<input type='text'  name='startDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000' value='"+ startDate +"'>").datepicker({format: "yyyy-dd-mm"});
		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		var dropdown_template =$("<div class='item-action dropdown'>" 
					+"<a href='javascript:void(0)' data-toggle='dropdown' class='icon'>"
					+"<i class='fe fe-more-vertical'></i></a><div class='dropdown-menu dropdown-menu-right'>"
					+"<a href='javascript:void(0)' class='dropdown-item edit' data-plan-id='"+$(this).parent().parent().parent().find('tr')+
					+"' data-module-id='"+$(this).parent().parent().parent().find('tr')+"><i class='dropdown-icon fe fe-edit-2'></i> Edit </a><a href='javascript:void(0)' class='dropdown-item delete' data-id='"
					+$(this).parent().parent().parent().find('tr') +"'><i class='dropdown-icon fe fe-message-square'></i> Delete</a></div></div></td></tr>");


		$(this).parent().parent().parent().prev().prev().prev().html(instructor);
		$(this).parent().parent().parent().prev().prev().html(startDateJS);
		$(this).parent().parent().parent().prev().html(endDateJS);
		$(this).parent().parent().html("").append(dropdown_template);
		
		
		var setData = {
				id : id,
				instructor : instructor,
				startDate : startDate,
				endDate : endDate
		};
		$.ajax({
			url: "http://localhost:8080/api/planDetail/" + id,
			data: JSON.stringify(setData),
			type: "patch",
			contentType: "application/json",
			dataType: "json",
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log(response);
			}
		});
	});
	
	$( "#module" ).autocomplete({
        source: function(request, response){
             $.ajax({
                        url: "http://localhost:8080/api/test/modules",
                    
                     data: {
                        name: request.term
                     },
                        dataType: "json",
                        success: function(data){
                              response ($.map(data, function(item){
                                 return {
                                   id: item.id,
                                   label: item.name,
                                   value: item.name,
                                   description: item.description
                                 		};
                         })
                     ); 
                  }
          });

        },
        autoFocus: true,
        minLength: 2,
        
        change: function(event, ui){
           var element = $(event.target);
           if (ui.item === null){
                  element.val("");
           }
        },
        select: function (event, ui) {        
            module_id = ui.item.id;
         
            return false;
    },
        messages: {
             noResults: function(count) {
               console.log("There were no matches.");
               $("#tags").attr("placeholder", "There were " + count + " matches");
             },
             results: function(count) {
               console.log("There were " + count + " matches")
               
             }
           }
        

        
      }).autocomplete( "instance" )._renderItem = function( ul, item ) {
          return $( "<li>" )
            .append( "<div>" + '<span data-id="' + item.id  + '" class="avatar avatar-' + colorize() + '">' + item.label.substring(0, 1) + '</span>' + "<strong class='result-icon'>" + item.label + "</strong>" + "<br>" + item.description + "</div>" )
            .appendTo( ul );
        };
        
      $("#module").autocomplete("option", "appendTo", "#planForm");
      
});
		
	function colorize()	{
		var colors = [
		       "blue",
		       "azure",
		       "indigo",
		       "purple",
		       "pink",
		       "red",
		       "orange",
		       "yellow",
		       "lime",
		       "green",
		       "teal",
		       "cyan",
		       "gray",
		       "gray-dark"
		];
		
		return colors[parseInt((Math.random() * colors.length) + 1)];
	}



