$(function () {

	var userTable = $("#userTable").DataTable({
				ajax: {
					url: "http://localhost:8080/api/users",
					dataSrc: ''
				},
				saveState: true,
				order: [[3, "desc"]],
				columns: [
					{data: "id"},
					{ 
						data:null, render: function(data, type, row){
							if (data.middleName === "N/A"){
								return "Not available";
							}
							if (data.middleName === ""){
								return data.firstName + " " + data.lastName;
							} else {
								return data.firstName + " " + data.middleName + " " + data.lastName;
							}
							
							
						} 
					},
					{ 
						data:null, render: function(data, type, row){
							return data.roleName.substring(data.roleName.indexOf("_") + 1);
						}
					},
					{ 
						data: null, render: function(data, type, row){
							return moment.utc(data.createdAt).format("MM/DD/YYYY");
						}
					},
					{
						data:null, render:function(data, type, row){
							return '<a href="#" class="btn btn-sm text-danger" data-action="reset"><i class="fas fa-redo" ></i> Reset Password </a>';
						}
					}
					
				],
				columnDefs: [
					{
						targets: 0, width: "5%"
					},
					{
						targets: 1, width: "60"
					},
					{
						targets: 2, width: "15%"
					},
					{
						targets: 3,  width: "15%"
					},
					{
						targets: -1, width: "5%", "sortable" : false, "searchable": false, "orderable" : false
					}

				]
			});

	

		$('#userForm input').on("blur",function(){
			var firstNameEl = $("input[name=firstName]");
			var lastNameEl = $("input[name=lastName]");
			var excludeField = $(this).attr('name');
				if(excludeField != "middleName"){
					if( $(this).val().length >= 2 ) {
				        $(this).removeClass('is-invalid').addClass('is-valid');
				        if (firstNameEl.val() != "" && lastNameEl.val() != ""){
				        	$("input[name=username]").val(getUsername(firstNameEl, lastNameEl));
				        } else {
				        	return;
				        }
				        
				    } else {
				    	$(this).removeClass("is-valid").addClass('is-invalid');
				    	$("input[name=username]").val("");
				    }
				}
				    
		});
	
	
	/*$("#userForm input").on('blur', function (){

		var firstNameEl = $("input[name=firstName]");
		var lastNameEl = $("input[name=lastName]");
		var firstMessage = firstNameEl.next().next().html();
		var lastMessage = lastNameEl.next().next().html();
		if (firstNameEl.val() !== "" && lastNameEl.val() !== "" && firstNameEl.val().length >= 2 && lastNameEl.val().length >= 2){
			$("input[name=username]").val(getUsername(firstNameEl, lastNameEl));
			$("input[name=username]").removeClass('is-invalid').addClass('is-valid').next().next().html("Looks good.");
		} else {
			firstNameEl.removeClass('is-valid').addClass('is-invalid').next().next().html(firstMessage);
			lastNameEl.removeClass('is-valid').addClass('is-invalid').next().next().html(lastMessage);
			$("input[name=username]").val("").removeClass("is-valid").addClass("is-invalid");
		}
	});*/
	
	
	$("#btnAddUser").on('click', function(event){
		var form = $("#userForm");
		var username = $("input[name=username]");

			$.ajax({
				url: "http://localhost:8080/api/users",
				type: "post",
				contentType: "application/json",
				dataType: 'json',
				data: transformToJSON(form),
				success: function(response){
					$("#addUserModal").modal('hide');
					userTable.ajax.reload();
					alert(response.message);
				},
				error: function(response){
					var errors = response.responseJSON.errors;
					for (var field in errors){
						$("[name=" + field + "]").removeClass("is-valid").addClass("is-invalid").next().next().html(errors[field]);
					}
				}
			});
	});
	
	function getUsername(firstName, lastName){
			return firstName.val().toLowerCase().charAt(0) + "." + lastName.val().toLowerCase();
	}
	
	
	function getUsers(){
		var users;
		$.ajax({
			url: "http://localhost:8080/api/user",
			contentType: "application/json",
			type: "get",
			success:function(response){
				users= response;
			}
		});
		return users;
	}
	
	
	$("#addUserModal").on("hidden.bs.modal", function(e){
		$(this).find("input").each(function(index, input){
			var element = $(input);
			if (! element.attr("type") === "hidden"){
				$(input).val("").removeClass("is-valid is-invalid");
			}
			
			
		});
	});
	
	$("#userTable tbody").on("click", "a[data-action=reset]", function() {
		var row_data = userTable.row($(this).parents("tr")).data();
	
		$.ajax({
			url: "http://localhost:8080/api/user/reset/" + row_data.id ,
			contentType: "application/json",
			dataType: "json",
			type: "patch",
			success:function(response){
				toastr.success(response.message, "Resetting password",  {
					  "progressBar": true
				});
			}
		});
	});
	
});