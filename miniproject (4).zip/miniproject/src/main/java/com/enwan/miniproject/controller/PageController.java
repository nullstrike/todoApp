package com.enwan.miniproject.controller;

import org.springframework.web.servlet.ModelAndView;

public class PageController {
	public static ModelAndView pageLoader(String viewname) {
		ModelAndView page = new ModelAndView();
		page.setViewName(viewname);
		return page;
	}
	public static ModelAndView pageLoader(String content, String section) {
		ModelAndView page = new ModelAndView();
		page.addObject("content", content);
		page.addObject("section", section);
		page.setViewName("layouts/template");
		return page;
	}
	
}
