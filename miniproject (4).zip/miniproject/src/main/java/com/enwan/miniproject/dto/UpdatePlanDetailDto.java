package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdatePlanDetailDto {

	private Integer id;
	
    private String instructor;
    
    private Date startDate;
    
    private Date endDate;
    
    private Integer status;
    
}
