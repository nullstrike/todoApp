package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreateModuleDto;
import com.enwan.miniproject.dto.UpdateModuleDto;
import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.repository.ModuleRepository;

@Service
public class ModuleService implements IModuleService {

	@Autowired
	private ModuleRepository moduleRepository;
	
	
	@Override
	public Module createModule(CreateModuleDto createModule) {
		Module module = new Module();
		module.setName(createModule.getName());
		module.setDescription(createModule.getDescription());
		return moduleRepository.save(module);
	}

	@Override
	public void updateModule(UpdateModuleDto updateModule) {
		Module module = moduleRepository.findById(updateModule.getModuleId()).orElseThrow(() -> new RuntimeException("No module found. "));
		module.setName(updateModule.getName());
		module.setDescription(updateModule.getDescription());
		moduleRepository.save(module);
	}

	@Override
	public void deleteModuleById(Integer id) {
		Module module = moduleRepository.findById(id).orElseThrow(() -> new RuntimeException("No module found."));
		moduleRepository.delete(module);
	}

	@Override
	public List<ViewModuleDto> findAllModule() {
		return moduleRepository.findAllModules();
	}

}
