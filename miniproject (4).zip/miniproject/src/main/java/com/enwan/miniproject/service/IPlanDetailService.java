package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;

public interface IPlanDetailService {
	
	void savePlanDetail(CreatePlanDetailDto createPlanDetail);
	
	void updatePlanDetail(UpdatePlanDetailDto updatePlanDetail);

	void deletePlanDetailById(Integer id);
	
	List<ViewPlanDetailDto> findAllPlan(Integer id);

}
