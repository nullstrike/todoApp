package com.enwan.miniproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.ChangePasswordDto;
import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.UserDetailDto;

import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.IUserService;


@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	private IUserService userService;
	
	
	@PostMapping("/users")
	public ResponseEntity<?> createUser(@Valid @RequestBody CreateUserDto createUserDto){
		if (userService.checkUsernameExist(createUserDto.getUsername())) {
			return new ResponseEntity<>(new RequestResponse(false, "Username already taken"), HttpStatus.BAD_REQUEST);
		}
		
		userService.createUser(createUserDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created user."), HttpStatus.OK);
	}
	
	@GetMapping("/users")
	public List<UserDetailDto> getUsers(){
		return userService.getUsers();
	}
	
	@PatchMapping("/users")
	public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordDto changePasswordDto) {
		if (! userService.checkPasswordMatches(changePasswordDto.getUsername(), changePasswordDto.getCurrentPassword())) {
			return new ResponseEntity<>(new RequestResponse(false, "Current password is incorrect"), HttpStatus.BAD_REQUEST);
	}
		userService.changePassword(changePasswordDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully updated password"), HttpStatus.OK);
	}
	
	@PatchMapping("/user/reset/{id}")
	public ResponseEntity<?> resetPassword(@PathVariable("id") Integer id){
		userService.resetPassword(id);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully reset the password"), HttpStatus.OK);
	}
	
	
	
}
