package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.CreateModuleDto;
import com.enwan.miniproject.dto.UpdateModuleDto;
import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.model.Module;

public interface IModuleService {
	

	Module createModule(CreateModuleDto moduleDto);
	
	void updateModule (UpdateModuleDto moduleDtoUpdate);

	void deleteModuleById(Integer id);
	
	List<ViewModuleDto> findAllModule();

}
