package com.enwan.miniproject.model;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Getter
@Setter
@Entity
@Table(name = "task")
public class Task {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TaskID")
	private Integer id;
	
	@Column(name = "Content", columnDefinition = "text", nullable = false)
	private String content;
	
	@Column(name = "TaskType", nullable = false, columnDefinition = "enum('Done', 'Challenges', 'Todo')")
	private String type;
	
	@Column(name = "TaskDate", nullable = false, columnDefinition="DATE")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date date;
	
	@ManyToOne
	@JoinColumn(name = "UserID", nullable = false)
	@JsonIgnore
	private User user;

	public Task() {

	}
	
	
}
