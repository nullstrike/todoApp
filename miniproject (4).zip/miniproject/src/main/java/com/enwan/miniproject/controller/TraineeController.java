package com.enwan.miniproject.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
@RequestMapping("/trainee")
public class TraineeController extends PageController {


	
	@GetMapping
	public ModelAndView index() {
		return pageLoader("trainee/index", "default_trainee");
	}
	
	@GetMapping("/report")
	public ModelAndView dailyReport() {
		return pageLoader("trainee/report", "trainee");
	}
	
	
	
}
