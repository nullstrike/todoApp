package com.enwan.miniproject.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewPlanDto {
	
	private Integer planId;
	
	private String name;
}
