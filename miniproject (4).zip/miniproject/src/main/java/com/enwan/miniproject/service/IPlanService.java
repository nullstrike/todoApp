package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.CreatePlanDto;
import com.enwan.miniproject.dto.UpdatePlanDto;
import com.enwan.miniproject.dto.ViewPlanDto;


public interface IPlanService {
	
	List<ViewPlanDto> getAllPlans();
	
	Integer savePlan(CreatePlanDto createPlan);
	
	void deletePlanById(Integer id);
	
	void updatePlan (UpdatePlanDto updatePlan);
}
