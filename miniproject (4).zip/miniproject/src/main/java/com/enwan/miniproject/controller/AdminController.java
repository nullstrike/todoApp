package com.enwan.miniproject.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/admin")
public class AdminController extends PageController {

	@GetMapping
	public ModelAndView index() {
		return pageLoader("admin/index", "admin");
	}
	
}
