package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreatePlanDto;
import com.enwan.miniproject.dto.UpdatePlanDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.repository.PlanRepository;

@Service
public class PlanService implements IPlanService {

	@Autowired
	private PlanRepository planRepository;
	
	@Override
	public List<ViewPlanDto> getAllPlans() {
		return planRepository.findAllPlans();
	}

	@Override
	public Integer savePlan(CreatePlanDto createPlan) {
		Plan plan = new Plan();
		plan.setName(createPlan.getName());
		Integer planId = planRepository.save(plan).getId();
		return planId;
	}

	@Override
	public void deletePlanById(Integer id) {
		Plan plan = planRepository.findById(id).get();
		planRepository.delete(plan);
	}

	@Override
	public void updatePlan(UpdatePlanDto updatePlan) {
		Plan plan = planRepository.findById(updatePlan.getId()).get();
		plan.setName(updatePlan.getName());
		planRepository.save(plan);
		
	}

}
