package com.enwan.miniproject.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateModuleDto {
	
	private Integer moduleId;
	
	private String name;
	
	private String description;

}
