package com.enwan.miniproject.handler;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.enwan.miniproject.model.User;
import com.enwan.miniproject.service.IUserService;
import com.enwan.miniproject.service.UserPrincipal;

public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

	@Autowired
	private IUserService userService;
	
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		
		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
		for (GrantedAuthority authority: authorities) {
			if (authority.getAuthority().equals("ROLE_TRAINEE")) {
				response.sendRedirect("/trainee");
			} else if (authority.getAuthority().equals("ROLE_FACILITATOR")) {
				response.sendRedirect("/facilitator");
			} else {
				response.sendRedirect("/admin");
			}
		}
		  
		UserPrincipal userPrincipal = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = userService.findByUsername(userPrincipal.getUsername());
		String user_role = authentication.getAuthorities().stream().findAny().get().getAuthority();
		request.getSession().setAttribute("username", authentication.getName());
		request.getSession().setAttribute("userrole", user_role.substring(user_role.indexOf("_") + 1, user_role.length()));
		request.getSession().setAttribute("fullname", userService.getNames(authentication.getName()));
		request.getSession().setAttribute("user_id", user.getId());
		
		
	}
	
}
