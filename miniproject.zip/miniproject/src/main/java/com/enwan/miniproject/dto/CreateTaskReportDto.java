package com.enwan.miniproject.dto;


public class CreateTaskReportDto {

	private Integer userId;
	
	private String text;
	
	private String type;

	public CreateTaskReportDto(Integer userId, String text, String type) {
		this.userId = userId;
		this.text = text;
		this.type = type;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	

	
}
