package com.enwan.miniproject.dto;

import java.time.LocalDate;


public class UpdatePlanDetailDto {


    private String instructor;
    
    private LocalDate startDate;
    
    private LocalDate endDate;

	
	public UpdatePlanDetailDto(String instructor, LocalDate startDate, LocalDate endDate) {
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public UpdatePlanDetailDto() { }

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

    
    
    
}
