package com.enwan.miniproject.dto;


public class UserStatusDto {

	private Integer id;
	
	private Integer planId;
	
	private Integer moduleId;
	
	private String moduleName;
	
	private Integer status;

	public UserStatusDto() {}
	
	public UserStatusDto(Integer id, Integer planId, Integer moduleId, String moduleName, Integer status) {
		this.id = id;
		this.planId = planId;
		this.moduleId = moduleId;
		this.moduleName = moduleName;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
}
