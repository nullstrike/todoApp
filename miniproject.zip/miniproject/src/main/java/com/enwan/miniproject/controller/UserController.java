package com.enwan.miniproject.controller;

import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.enwan.miniproject.dto.ChangePasswordDto;
import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.TraineeDetailDto;
import com.enwan.miniproject.dto.UpdateStatusDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.IUserService;
import com.enwan.miniproject.service.TraineeService;


@RestController
@RequestMapping("/api/user")
public class UserController {
	
	private final IUserService userService;
	
	private final TraineeService traineeService;
	
	@Autowired
	public UserController(IUserService userService, TraineeService traineeService) {
		this.userService = userService;
		this.traineeService = traineeService;
	}

	@PostMapping
	public ResponseEntity<?> createUser(@Valid @RequestBody CreateUserDto createUserDto){
		if (userService.checkUsernameExist(createUserDto.getUsername())) {
			return new ResponseEntity<>(new RequestResponse(false, "Username already taken"), HttpStatus.BAD_REQUEST);
		}
		
		userService.createUser(createUserDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created user."), HttpStatus.OK);
	}
	
	@GetMapping
	public List<UserDetailDto> getUsers(){
		return userService.getUsers();
	}
	
	@GetMapping("/trainees")
	public List<TraineeDetailDto> getUserTrainees(){
		return userService.getUserTrainees();
	}
	
	@GetMapping("/trainees/{id}")
	public List<TraineeDetailDto> getUserTraineesPerPlan(@PathVariable("id") Integer id){
		return userService.getUserTraineesPerPlan(id);
	}
	
	@GetMapping("/trainees/status/{id}")
	public ResponseEntity<?> getUserStatusById(@PathVariable("id") Integer id){
		return new ResponseEntity<>(userService.getUserStatusById(id), HttpStatus.OK);
	}
	
	@PutMapping
	public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordDto changePasswordDto) {
		if (! userService.checkPasswordMatches(changePasswordDto.getUsername(), changePasswordDto.getCurrentPassword())) {
			return new ResponseEntity<>(new RequestResponse(false, "Current password is incorrect"), HttpStatus.BAD_REQUEST);
	}
		userService.changePassword(changePasswordDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully updated password"), HttpStatus.OK);
	}
	
	@PutMapping("/reset/{id}")
	public ResponseEntity<?> resetPassword(@PathVariable("id") Integer id){
		userService.resetPassword(id);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully reset the password"), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable("id") Integer id){
		userService.deleteUser(id);
		return ResponseEntity.ok(new RequestResponse(true, "Successfully deleted user."));
	}
	
	@GetMapping("/find")
	public ResponseEntity<?> filterTrainees(@RequestParam Map<String, String> params){
		return new ResponseEntity<>(userService.getTraineesByName(params.get("name")), HttpStatus.OK);
	}
	
	@GetMapping("/find/userplan")
	public ResponseEntity<?> getTraineesNotInPlan(@RequestParam Map<String, String> params){
		return ResponseEntity.ok(userService.getTraineesNotInPlan(params.get("name")));
	}
	
	@GetMapping("/plan/{id}")
	public ResponseEntity<?> getTraineesById(@PathVariable("id") Integer id){
		return new ResponseEntity<>(userService.getExistingTraineesByPlan(id), HttpStatus.OK);
	}
	
	@DeleteMapping("/plan/{id}")
	public ResponseEntity<?> removeTraineesInPlan(@PathVariable("id") Integer id){
		userService.deleteByUserPlan(id);
		return new ResponseEntity<>("Trainee successfully remove to the plan", HttpStatus.OK);
	}
	
	@GetMapping("/report/{id}")
	public ResponseEntity<?> getId(@PathVariable("id") Integer id){
		User user = userService.getUserbyId(id);
		return new ResponseEntity<>(traineeService.getTaskByUser(user), HttpStatus.OK);
	}
	
	
	@PutMapping("trainees/status")
	public ResponseEntity<?> updateStatusById(@RequestBody UpdateStatusDto updateStatusDto){
		userService.updateStatus(updateStatusDto.getUser(),updateStatusDto.getModule(),updateStatusDto.getIsChecked());
		return new ResponseEntity<>("Successfully updated user status!", HttpStatus.OK);
	}
}
