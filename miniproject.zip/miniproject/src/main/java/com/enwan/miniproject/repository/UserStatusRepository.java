package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.NewTraineesDto;
import com.enwan.miniproject.dto.UserStatusDto;
import com.enwan.miniproject.model.UserStatus;

@Repository
public interface UserStatusRepository extends JpaRepository<UserStatus, Integer> {
	
	@Query(" select new com.enwan.miniproject.dto.UserStatusDto(u.user.id, u.plan.id, d.module.id, d.module.name, s.status) from UserStatus s inner join UserPlan u on u.id = s.userPlan.id inner join PlanDetail d on d.id = s.planDetail.id where u.user.id = :user order by d.module.id desc ")
	List<UserStatusDto> getUserStatusById(@Param("user") Integer user);
	
	@Query("SELECT new com.enwan.miniproject.dto.NewTraineesDto (a.planDetail.id) from UserStatus a join a.userPlan b where b.plan.id = :planId ")
	List<NewTraineesDto> getModulesNewTrainees(@Param("planId") Integer plan_id);
	
	@Query("SELECT new com.enwan.miniproject.dto.NewTraineesDto (a.id) from PlanDetail a join a.plan b where b.id = :plan_id")
	List<NewTraineesDto> getModulesNewTraineesPartial(@Param("plan_id") Integer plan_id);
	
	@Query("SELECT a from UserStatus a JOIN a.planDetail b WHERE a.userPlan.id = (SELECT c.id from UserPlan c where c.user.id = :user_id) AND b.module.id = :module_id ")
	List<UserStatus> setModuleStatus(@Param("user_id") Integer user_id, @Param("module_id") Integer module_id);
}
