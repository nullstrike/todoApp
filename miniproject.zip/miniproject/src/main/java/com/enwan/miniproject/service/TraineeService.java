package com.enwan.miniproject.service;



import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreateTaskReportDto;
import com.enwan.miniproject.dto.UserTaskDto;
import com.enwan.miniproject.model.Task;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.repository.TaskRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class TraineeService {

	private final TaskRepository taskRepo;

	private final UserRepository userRepository;
	
	@Autowired
	public TraineeService(TaskRepository taskRepo, UserRepository userRepository) {
		this.taskRepo = taskRepo;
		this.userRepository = userRepository;
	}
	
	public List<Task> getAllTasks(){
		return taskRepo.findAll();
	}
	
	public void saveTask(List<CreateTaskReportDto> tasks) {
		for(int i=0; i<tasks.size(); i++) {
			Task task = new Task();
			User user = userRepository.findById(tasks.get(i).getUserId()).get();
			task.setContent(tasks.get(i).getText());
			task.setTaskDate(LocalDate.now());
			task.setTaskType(tasks.get(i).getType());
			task.setUser(user);
			taskRepo.save(task);
		}
	}

	public User getUser(@Valid UserTaskDto userTaskDto) {
		return userRepository.findById(userTaskDto.getUserId()).orElseThrow(() -> new RuntimeException("No user found."));
	}
	
	public List<Task> getTaskByUser (User user){
		return taskRepo.getTaskByUser(user);
	}
	
	public User findUser(Integer id) {
		return userRepository.findById(id).orElseThrow(() -> new RuntimeException("No user found."));
	}
	
}
