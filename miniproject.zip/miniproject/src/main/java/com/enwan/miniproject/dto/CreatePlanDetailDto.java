package com.enwan.miniproject.dto;

import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


public class CreatePlanDetailDto {

	private List<Integer> userPlanIds;
	
	private Integer planId;
	
	@NotNull(message = "Current name field should not be null")
	private Integer moduleId;
	
	@NotNull(message = "Current instructor field should not be null")
	@NotEmpty(message = "Current instructor field should not be empty")
	private String instructor;
	
	@NotNull(message = "Current Start Date field should not be null")
	private LocalDate startDate;
	
	@NotNull(message = "Current End Date field should not be null")
	private LocalDate endDate;

	public CreatePlanDetailDto() { }
	
	public CreatePlanDetailDto(List<Integer> userPlanIds, Integer moduleId, String instructor, LocalDate startDate, LocalDate endDate) {
		this.userPlanIds = userPlanIds;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public CreatePlanDetailDto(List<Integer> userPlanIds, Integer planId, Integer moduleId, String instructor, LocalDate startDate, LocalDate endDate) {
		this.userPlanIds = userPlanIds;
		this.planId = planId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public List<Integer> getUserPlanIds() {
		return userPlanIds;
	}

	public void setUserPlanIds(List<Integer> userPlanIds) {
		this.userPlanIds = userPlanIds;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}


	public LocalDate getStartDate() {
		return startDate;
	}


	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}


	public LocalDate getEndDate() {
		return endDate;
	}


	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	

	
	
	

	
}
