package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.NewTraineesDto;
import com.enwan.miniproject.dto.PlanDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailStatusDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.dto.ViewUserPlanDto;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.model.UserPlan;
import com.enwan.miniproject.model.UserStatus;
import com.enwan.miniproject.repository.PlanDetailRepository;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.UserPlanRepository;
import com.enwan.miniproject.repository.UserRepository;
import com.enwan.miniproject.repository.UserStatusRepository;

@Service
public class PlanService implements IPlanService {


	private final PlanRepository planRepository;

	private final UserRepository userRepository;
	
	private final UserPlanRepository userPlanRepository;
	
	private final UserStatusRepository userStatusRepository;
	
	private final PlanDetailRepository planDetailRepository;
	
	private static final int DEFAULT_STATUS = 0;
	
	@Autowired
	public PlanService(PlanRepository planRepository, UserRepository userRepository,
			UserPlanRepository userPlanRepository, UserStatusRepository userStatusRepository,
			PlanDetailRepository planDetailRepository) {
		this.planRepository = planRepository;
		this.userRepository = userRepository;
		this.userPlanRepository = userPlanRepository;
		this.userStatusRepository = userStatusRepository;
		this.planDetailRepository = planDetailRepository;
	}

	@Override
	public List<ViewPlanDto> getAllPlans() {
		return planRepository.findAllPlans();
	}

	@Override
	public Plan createPlan(PlanDto createPlan) {
		Plan plan = new Plan();
		plan.setName(createPlan.getName());
		Plan createdPlan = planRepository.save(plan);
		
		
		for (int i = 0; i < createPlan.getTrainees().size(); i ++) {
			UserPlan userPlan = new UserPlan();
			User user = userRepository.findById(createPlan.getTrainees().get(i)).get();
			userPlan.setPlan(createdPlan);
			userPlan.setUser(user);
			userPlanRepository.save(userPlan);
		}
		
		return createdPlan;
	}

	@Override
	public void deletePlanById(Integer id) {
		Plan plan = planRepository.findById(id).get();
		planRepository.delete(plan);
	}

	@Override
	public void updatePlan(Integer id, PlanDto updatePlan) {
		Plan plan = planRepository.findById(id).get();
		plan.setName(updatePlan.getName());

		List<NewTraineesDto> newTraineesModules = getModulesNewTrainees(id);
		for (int i = 0; i < updatePlan.getTrainees().size(); i++) {
			UserPlan userPlan = new UserPlan();
			User user = userRepository.findById(updatePlan.getTrainees().get(i)).get();
			userPlan.setPlan(plan);
			userPlan.setUser(user);
			UserPlan savedUserPlan = userPlanRepository.save(userPlan);
			
			for (int j = 0; j < newTraineesModules.size(); j++) {
		
				PlanDetail planDetail = planDetailRepository.findById(newTraineesModules.get(j).getId()).get();
				UserStatus userStatus = new UserStatus();
				userStatus.setPlanDetail(planDetail);
				userStatus.setUserPlan(savedUserPlan);
				userStatus.setStatus(DEFAULT_STATUS);
				userStatusRepository.save(userStatus);
			}

		}

		planRepository.save(plan);

	}

	@Override
	public List<ViewPlanDetailDto> getPlanById(Integer planId) {
		List<ViewPlanDetailDto> planDetail = planRepository.findAllBy(planId);
		return planDetail;
	}

	@Override
	public ViewUserPlanDto findPlanById(Integer UserId) {
		ViewUserPlanDto plan = userPlanRepository.findAllBy(UserId);
		return plan;
	}

	@Override
	public List<NewTraineesDto> getNewTrainees(Integer planId) {
		List<NewTraineesDto> newTrainees = userPlanRepository.getNewlyAddedTrainees(planId);
		return newTrainees;
	}

	@Override
	public List<NewTraineesDto> getModulesNewTrainees(Integer planId) {
		List<NewTraineesDto> newTraineesModules = userStatusRepository.getModulesNewTraineesPartial(planId);
		return newTraineesModules;
	}

	@Override
	public List<ViewPlanDetailStatusDto> getCurrentModules(Integer planId, Integer userId) {
		planDetailRepository.findOngoingModules(planId, userId)
			.forEach(userstatus -> {
				userstatus.setStatus(1);
				userStatusRepository.save(userstatus);
			});
		return planRepository.getAllModules(planId, userId);

	}

}
