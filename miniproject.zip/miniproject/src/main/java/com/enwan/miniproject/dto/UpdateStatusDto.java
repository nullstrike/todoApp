package com.enwan.miniproject.dto;


public class UpdateStatusDto {

	private Integer user;
	
	private Integer module;
	
	private Boolean isChecked;

	public UpdateStatusDto(Integer user, Integer module, Boolean isChecked) {
		this.user = user;
		this.module = module;
		this.isChecked = isChecked;
	}
	
	public UpdateStatusDto(){}

	public Integer getUser() {
		return user;
	}

	public void setUser(Integer user) {
		this.user = user;
	}

	public Integer getModule() {
		return module;
	}

	public void setModule(Integer module) {
		this.module = module;
	}

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	};
	
	
	
}
