package com.enwan.miniproject.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.NewTraineesDto;
import com.enwan.miniproject.dto.ViewUserPlanDto;
import com.enwan.miniproject.model.UserPlan;

@Repository
public interface UserPlanRepository extends JpaRepository<UserPlan, Integer> {
	
	@Query("SELECT new com.enwan.miniproject.dto.ViewUserPlanDto(a.plan.id) from UserPlan a join a.user b WHERE b.id = :UserId")
	ViewUserPlanDto findAllBy(@Param("UserId") Integer UserId);
	
	@Query("SELECT new com.enwan.miniproject.dto.NewTraineesDto (a.id) from UserPlan a where a.id NOT IN (SELECT b.userPlan.id FROM UserStatus b) and a.plan.id = :plan_id ")
	List<NewTraineesDto> getNewlyAddedTrainees(@Param("plan_id") Integer plan_id);
	
}
