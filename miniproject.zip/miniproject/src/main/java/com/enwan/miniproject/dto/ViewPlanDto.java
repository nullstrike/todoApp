package com.enwan.miniproject.dto;


public class ViewPlanDto {
	
	private Integer planID;
	
	private String name;

	public ViewPlanDto(String name) {
		this.name = name;
	}

	public ViewPlanDto() {
	}

	
	public ViewPlanDto(Integer planID, String name) {
		this.planID = planID;
		this.name = name;
	}

	public Integer getPlanID() {
		return planID;
	}

	public void setPlanID(Integer planID) {
		this.planID = planID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ViewPlanDto [planID=" + planID + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((planID == null) ? 0 : planID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ViewPlanDto other = (ViewPlanDto) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (planID == null) {
			if (other.planID != null)
				return false;
		} else if (!planID.equals(other.planID))
			return false;
		return true;
	}
	
	
}
