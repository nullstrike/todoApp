package com.enwan.miniproject.dto;

public class UserPlanDto {
	
	private Integer id;
	
	private String text;

	private Integer userPlanId;
	
	public UserPlanDto(Integer id, String text) {
		this.id = id;
		this.text = text;
	}

	public UserPlanDto(Integer id, String text, Integer userPlanId) {
		this.id = id;
		this.text = text;
		this.userPlanId = userPlanId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Integer getUserPlanId() {
		return userPlanId;
	}

	public void setUserPlanId(Integer userPlanId) {
		this.userPlanId = userPlanId;
	}

	
	
	
	
	
}
