package com.enwan.miniproject.dto;

public class ViewUserPlanDto {
	
	private Integer id;

	public ViewUserPlanDto(Integer id) {
		this.id = id;
	}

	public ViewUserPlanDto() { }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
