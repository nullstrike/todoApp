package com.enwan.miniproject.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.dto.TraineeDetailDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.dto.UserPlanDto;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.Role;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.model.UserStatus;


@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	
	 User findByUsername(String username);
	
	 Boolean existsByUsername(String username);

	 @Query("select new com.enwan.miniproject.dto.UserDetailDto(e.id, e.firstName, e.middleName, e.lastName, e.role.roleName, e.createdAt) from User e where e.role.roleName IS NOT :admin")
	 List<UserDetailDto> userDetailView(@Param("admin") String admin);
	 
	 @Query("select new com.enwan.miniproject.dto.TraineeDetailDto(e.id, e.firstName, e.middleName, e.lastName, e.role.roleName, e.createdAt, u.plan.id) from User e inner join UserPlan u on u.user.id = e.id where e.role.roleName IS :trainee")
	 List<TraineeDetailDto> traineeDetailView(@Param("trainee") String trainee);
	 
	 @Query("select new com.enwan.miniproject.dto.TraineeDetailDto(e.id, e.firstName, e.middleName, e.lastName, e.role.roleName, e.createdAt, u.plan.id) from User e inner join UserPlan u on u.user.id = e.id where e.role.roleName IS :trainee AND u.plan.id = :planId")
	 List<TraineeDetailDto> traineePerPlanView(@Param("trainee") String trainee,@Param("planId") Integer planId);
	 
	 @Query("select new com.enwan.miniproject.dto.NamesOnlyDto(a.firstName, a.lastName, a.role.roleName) from User a where username = :username")
	 NamesOnlyDto NamesView(@Param("username") String username);

	 @Query("select new com.enwan.miniproject.dto.UserPlanDto(a.id, CONCAT(a.firstName, ' ',a.lastName)) from User a where a.role = :role and (UPPER(a.lastName) LIKE CONCAT('%',UPPER(:name),'%') or  UPPER(a.firstName) LIKE CONCAT('%',UPPER(:name),'%'))")
	 List<UserPlanDto> filterTraineesByName(@Param("role") Role role, @Param("name") String name);
	 
	 @Query("select new com.enwan.miniproject.dto.UserPlanDto(b.id, CONCAT(a.firstName, ' ', a.lastName), b.id) from User a join a.userPlans b where a.id IN (SELECT user from UserPlan) and  a.role.id =  1 and b.plan = :planId ")
	 List<UserPlanDto> filterTraineesByPlan(@Param("planId") Plan planId);
	 
	 @Query("select new com.enwan.miniproject.dto.UserPlanDto(a.id, CONCAT(a.firstName, ' ',a.lastName)) from User a where a.id NOT IN (SELECT user from UserPlan) and a.role = :role and (UPPER(a.lastName) LIKE CONCAT('%',UPPER(:name),'%') or  UPPER(a.firstName) LIKE CONCAT('%',UPPER(:name),'%'))")
	 List<UserPlanDto> getTraineesNotInPlan(@Param("role") Role role, @Param("name") String name);
	 
	 @Query("SELECT a.status from UserStatus a JOIN a.planDetail b WHERE a.userPlan.id = (SELECT c.id from UserPlan c where c.user.id = :user_id) AND b.module.id = :module_id ")
	 List<UserStatus> setModuleStatus(@Param("user_id") Integer user_id, @Param("module_id") Integer module_id); 
	 
}
