package com.enwan.miniproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "plan")
public class Plan extends Auditing {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PlanId")
    private Integer id;

    @Column(name = "PlanName", nullable = false)
    private String name;

    @OneToMany(mappedBy = "plan", orphanRemoval = true)
    @JsonIgnore
    private Set<UserPlan> userPlans;

    @OneToMany(mappedBy = "plan", orphanRemoval = true)
    @JsonIgnore
    private Set<PlanDetail> planDetails;
    
    public Plan() { }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<UserPlan> getUserPlans() {
		return userPlans;
	}

	public void setUserPlans(Set<UserPlan> userPlans) {
		this.userPlans = userPlans;
	}

	public Set<PlanDetail> getPlanDetails() {
		return planDetails;
	}

	public void setPlanDetails(Set<PlanDetail> planDetails) {
		this.planDetails = planDetails;
	}
	
    
}
