package com.enwan.miniproject.dto;

import java.time.LocalDate;

public class PlanDetailDto {
	
	private Integer id;
	
	private Integer planId;
	
	private String planName;
	
	private Integer moduleId;
	
	private String name; 
	
	private String description;
	
	private String instructor;
	
	private LocalDate startDate;
	
	private LocalDate endDate;

	public PlanDetailDto() { }
	
	public PlanDetailDto(Integer id, Integer planId, String planName, Integer moduleId, String name, String description,
			String instructor, LocalDate startDate, LocalDate endDate) {
		this.id = id;
		this.planId = planId;
		this.planName = planName;
		this.moduleId = moduleId;
		this.name = name;
		this.description = description;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

		

	
	
}
