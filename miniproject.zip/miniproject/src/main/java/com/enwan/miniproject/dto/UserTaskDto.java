package com.enwan.miniproject.dto;

public class UserTaskDto {
	
	private Integer userId;
	
	private String date;

	public UserTaskDto() { }

	public UserTaskDto(Integer userId, String date) {
		this.userId = userId;
		this.date = date;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
}
