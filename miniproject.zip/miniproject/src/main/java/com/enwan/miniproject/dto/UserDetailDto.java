package com.enwan.miniproject.dto;

import java.time.Instant;


public class UserDetailDto {
	

	private Integer id;

	private String firstName;
	
	private String middleName;
	
	private String lastName;
	
	private String roleName;
	
	private Instant createdAt;

	public UserDetailDto() { }

	public UserDetailDto(Integer id, String firstName, String middleName, String lastName, String roleName,
			Instant createdAt) {
		this.id = id;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.roleName = roleName;
		this.createdAt = createdAt;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	} 
	
	
	
}
