package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.ChangePasswordDto;
import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.TraineeDetailDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.dto.UserPlanDto;
import com.enwan.miniproject.dto.UserStatusDto;
import com.enwan.miniproject.model.User;

public interface IUserService {
	User createUser(CreateUserDto createUserDto);
	
	User changePassword(ChangePasswordDto changePasswordDto);
	
	Boolean checkUsernameExist(String username);
	
	Boolean checkPasswordMatches(String username, String raw);
	
	List<UserDetailDto> getUsers();
	
	List<TraineeDetailDto> getUserTrainees();
	
	String getNames(String username);
	
	User findByUsername(String username);
	
	void resetPassword(Integer id);
	
	List<UserPlanDto> getTraineesByName(String name);
	
	List<UserPlanDto> getTraineesNotInPlan(String name);
	
	List<UserPlanDto> getExistingTraineesByPlan(Integer planId);
	
	void deleteByUserPlan(Integer userPlanId);
	
	User getUserbyId (Integer id);

	List<UserStatusDto> getUserStatusById(Integer id);

	void updateStatus(Integer user, Integer module, Boolean isChecked);
	
	void deleteUser(Integer id);

	List<TraineeDetailDto> getUserTraineesPerPlan(Integer id);
}
