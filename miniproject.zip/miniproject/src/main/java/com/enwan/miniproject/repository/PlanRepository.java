package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailStatusDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Plan;

@Repository
public interface PlanRepository extends JpaRepository<Plan, Integer> {

	@Query("select new com.enwan.miniproject.dto.ViewPlanDto(a.id,a.name) from Plan a")
	List<ViewPlanDto> findAllPlans();
	
	@Query("SELECT DISTINCT new com.enwan.miniproject.dto.ViewPlanDetailDto"
			+ "(a.id, c.name, c.description, a.instructor, a.startDate, a.endDate) From PlanDetail a join a.plan b join a.module c where b.id = :plan_id")
	List<ViewPlanDetailDto> findAllBy(@Param("plan_id") Integer plan_id);
	
	@Query("SELECT new com.enwan.miniproject.dto.ViewPlanDetailStatusDto"
			+ "(b.id, c.name, c.description, b.instructor, b.startDate, b.endDate, a.status) FROM UserStatus a join a.planDetail b join b.module c "
			+ "WHERE a.userPlan.id = (SELECT d.id from UserPlan d WHERE d.plan.id = :plan_id and d.user.id = :user_id)")
	List<ViewPlanDetailStatusDto> getAllModules(@Param("plan_id") Integer plan_id, @Param("user_id") Integer user_id);
	
	
}
