package com.enwan.miniproject.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "module")
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"})
public class Module extends Auditing {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ModuleId")
    private Integer id;

    @Column(name = "ModuleName", nullable = false)
    private String name;

    @Column(name = "Description", nullable = false, columnDefinition = "TEXT")
    private String description;

    @OneToMany(mappedBy = "module", orphanRemoval = true)
    @JsonIgnore
    private Set<PlanDetail> planDetails;

    public Module() { }

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<PlanDetail> getPlanDetails() {
		return planDetails;
	}

	public void setPlanDetails(Set<PlanDetail> planDetails) {
		this.planDetails = planDetails;
	}

    
}

