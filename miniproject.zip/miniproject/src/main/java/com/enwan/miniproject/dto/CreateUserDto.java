package com.enwan.miniproject.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



public class CreateUserDto {
	

	@Size(min = 2, max = 40, message = "Firstname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String firstName;
	
	private String middleName;

	@Size(min = 2, max = 40, message = "Lastname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String lastName;
	
	@Size(max = 20, message = "Username must not more than 20 characters")
	private String username;
	
	@NotNull
	private Integer role;

	public CreateUserDto(String firstName, String middleName,  String lastName, String username, Integer role) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.username = username;
		this.role = role;
	}

	public CreateUserDto() { }

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}
	
	
	
	
	
	

}
