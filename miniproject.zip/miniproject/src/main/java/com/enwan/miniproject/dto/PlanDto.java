package com.enwan.miniproject.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class PlanDto {
	
	@NotNull(message = "Plan name field should not be null")
	@NotEmpty(message = "Plan name field should not be empty")
	private String name;

	
	private List<Integer> trainees;

	public PlanDto(String name, List<Integer> trainees) {
		this.name = name;
		this.trainees = trainees;
	}

	public PlanDto() { }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Integer> getTrainees() {
		return trainees;
	}

	public void setTrainees(List<Integer> trainees) {
		this.trainees = trainees;
	}

	

	
	
	
	
	
}
