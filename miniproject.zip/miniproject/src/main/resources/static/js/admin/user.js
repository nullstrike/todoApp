$(function () {

	var userTable = $("#userTable").DataTable({
				ajax: {
					url: "http://localhost:8080/api/user",
					dataSrc: ''
				},
				saveState: true,
				order: [[3, "desc"]],
				columns: [
					{data: "id"},
					{ 
						data:null, render: function(data, type, row){
							if (data.middleName === "N/A"){
								return "Not available";
							}
							if (data.middleName === ""){
								return data.firstName + " " + data.lastName;
							} else {
								return data.firstName + " " + data.middleName + " " + data.lastName;
							}
							
							
						} 
					},
					{ 
						data:null, render: function(data, type, row){
							return data.roleName.substring(data.roleName.indexOf("_") + 1);
						}
					},
					{ 
						data: null, render: function(data, type, row){
							return moment.utc(data.createdAt).format("MM/DD/YYYY");
						}
					},
					{
						data:null, render:function(data, type, row){
							return '<a class="btn btn-sm text-primary" data-action="reset" title="Reset password"><i class="fe fe-life-buoy" ></i></a>' +
								    '&nbsp;<a class="btn btn-sm text-danger" data-action="delete" title="Delete User"><i class="fe fe-trash"></i></a>';
						}
					}
					
				],
				columnDefs: [
					{
						targets: 0, width: "5%"
					},
					{
						targets: 1, width: "60"
					},
					{
						targets: 2, width: "15%"
					},
					{
						targets: 3,  width: "15%"
					},
					{
						targets: -1, width: "5%", "sortable" : false, "searchable": false, "orderable" : false
					}

				]
			});

	

		$('#userForm input').on("blur",function(){
			var firstNameEl = $("input[name=firstName]");
			var lastNameEl = $("input[name=lastName]");
			var excludeField = $(this).attr('name');
				if(excludeField != "middleName"){
					if( $(this).val().length >= 2 ) {
				        $(this).removeClass('is-invalid').addClass('is-valid');
				        if (firstNameEl.val() != "" && lastNameEl.val() != ""){
				        	$("input[name=username]").val(getUsername(firstNameEl, lastNameEl));
				        } else {
				        	return;
				        }
				        
				    } else {
				    	$(this).removeClass("is-valid").addClass('is-invalid');
				    	$("input[name=username]").val("");
				    }
				}
				    
		});

	$("#btnAddUser").on('click', function(event){
		var form = $("#userForm");
		var username = $("input[name=username]");

			$.ajax({
				url: "http://localhost:8080/api/user",
				type: "post",
				contentType: "application/json",
				dataType: 'json',
				data: transformToJSON(form),
				success: function(response){
					$("#addUserModal").modal('hide');
					userTable.ajax.reload();
					swal("Creating user", response.message, "success");
				},
				error: function(response){
					var errors = response.responseJSON.errors;
					for (var field in errors){
						$("[name=" + field + "]").removeClass("is-valid").addClass("is-invalid").next().next().html(errors[field]);
					}
				}
			});
	});
	
	function getUsername(firstName, lastName){
			return firstName.val().toLowerCase().charAt(0) + "." + lastName.val().toLowerCase();
	}
	
	
	function getUsers(){
		var users;
		$.ajax({
			url: "http://localhost:8080/api/user",
			contentType: "application/json",
			type: "get",
			success:function(response){
				users= response;
			}
		});
		return users;
	}
	
	
	$("#addUserModal").on('hidden.bs.modal', function(e){
		$(this).find("input").each(function(index, input){
			$(input).val("").removeClass("is-valid is-invalid");
			console.log($(input).attr("type"));
		});
		
	});
	
	$("#userTable tbody").on("click", "a[data-action=reset]", function() {
		var row_data = userTable.row($(this).parents("tr")).data();
	
		$.ajax({
			url: "http://localhost:8080/api/user/reset/" + row_data.id ,
			contentType: "application/json",
			dataType: "json",
			type: "put",
			success:function(response){
				toastr.success(response.message, "Resetting password",  {
					  "progressBar": true
				});
			}
		});
	});

	$("#userTable tbody").on("click", "a[data-action=delete]", function() {
		var row_data = userTable.row($(this).parents("tr")).data();
	  		swal({
	  	  		  title: 'Are you sure?',
	  	  		  text: "You won't be able to revert this!",
	  	  		  type: 'warning',
	  	  		  showCancelButton: true,
	  	  		  cancelButtonColor: '#3085d6',
	  	  		  confirmButtonColor: '#d33',
	  	  		  toast: true,
	  	  		  backdrop: false,
	  	  		  confirmButtonText: 'Yes, delete it!'
	  	  		}).then((result) => {
	  	  		  if (result.value) {
	  	  		   $(this).closest("tr").fadeOut(1000);
	  	 		$.ajax({
	  				url: "http://localhost:8080/api/user/" + row_data.id ,
	  				contentType: "application/json",
	  				dataType: "json",
	  				type: "delete",
	  				success:function(response){
	  					toastr.success(response.message, "Deleting user",  {
	  						  "progressBar": true
	  					});
	  				}
	  			});
	  	  		  }
	  	  		})

	});
});