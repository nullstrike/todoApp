$(function() {
    var plans = [
        [],
        []
    ];
    var modules = [];
    var defaultUrl = "http://localhost:8080/api/user/trainees";
    var count = 0;

    $.ajax({
        dataType: "json",
        url: "http://localhost:8080/api/modules",
        success: function(response) {
            for (var c = 0; c < response.length; c++) {
                modules.splice(modules.length, 0, [response[c].id, response[c].name]);
            }
        }
    });

    $.ajax({
        dataType: "json",
        url: "http://localhost:8080/api/plans",
        success: function(response) {
            for (var c = 0; c < response.length; c++) {
                plans[0].splice(plans[0].length, 0, [response[c].name, response[c].planID]);
            }
        }
    });
    
    // Get Modules Per Plan
    $.ajax({
        dataType: "json",
        url: "http://localhost:8080/api/plandetail",
    }).done(function(response) {

        if (response != []) {
            var id = 1;
            
         // Insert to plans[]
            var planIndex = 0;
            var currPlanId = 1;
            
            for (var i = 0; i < response.length; i++) {
                if (response === undefined) {
                    console.log('undefined');
                    break;
                } else {
                	if (response[i].planId > currPlanId) {
                		planIndex++;
                		currPlanId = response[i].planId
                        plans.splice(planIndex, 1, []);
                    }
                    plans[planIndex].splice(0,0,response[i].planId);
                    plans[planIndex].splice(1, 0, [response[i].name, response[i].moduleId]);
                    //plans[0].splice(plans[0].length, 0, [response[i].planName,response[i].planId]);
                }
            }
            
            // Anti Duplicate
            for (var c = 0; c < plans.length; c++) {
                var seen = {};
                var out = [];
                var len = plans[c].length;
                var j = 0;
                for (var i = 0; i < len; i++) {
                    var item = plans[c][i];
                    if (seen[item] !== 1) {
                        seen[item] = 1;
                        out[j++] = item;
                    }
                }
                plans[c] = out;
            }
            
            for (var c = 0; c < plans[0].length; c++) {
                var seen = {};
                var out = [];
                var len = plans[0][c].length;
                var j = 0;
                for (var i = 0; i < len; i++) {
                    var item = plans[0][c][i];
                    if (seen[item] !== 1) {
                        seen[item] = 1;
                        out[j++] = item;
                    }
                }
                plans[0][c] = out;
            }
            // Anti Duplicate
        } else {
            console.log("break ajax loop");
        }
        userTable(defaultUrl,"0");
 
    });

    function userTable(myUrl,myPlanId) {
        $("#userTable").DataTable({
            ajax: {
                url: myUrl,
                dataSrc: ''
            },
            saveState: true,
            order: [
                [3, "desc"]
            ],
            columns: [{
                    data: "id"
                },
                {
                    // Trainee Name
                    data: null,
                    render: function(data, type, row) {
                        if (data.middleName === "N/A") {
                            return data.firstName + " " + data.lastName;
                        } else {
                            return data.firstName + " " + data.middleName + " " + data.lastName;
                        }
                    }
                },
                {
                    // Module Multiselect
                    data: null,
                    render: function(data, type, row) {
                    	 var moduleMultiselect = '<select class="module-multiselect" multiple="multiple" name="' + data.id + '">';
                         var planName = "Plan";
                         var planIndex = 1;

                         for(var c = 1; c <= plans.length-1; c++) {
                         	if(data.planId === plans[c][0]){
                         		planIndex = c;
                         		break;
                         	} else {
                         		planIndex = 0;
                         	}
                         }
                    	
                        $.ajax({
                            dataType: 'json',
                            url: "http://localhost:8080/api/user/trainees/status/" + data.id
                        }).done(function(response) {
                            var completed = [];
                            for (var c = 0; c < response.length; c++) {
                                if (response[c].status === 2) {
                                    completed.splice(0, 0, response[c].moduleId);
                                }
                            }
                            $(".multiselect-container li.active").find('span').addClass("crossOut");
                            $('select[name=' + data.id + ']').multiselect('select', completed);

                            var progress = completed.length / (plans[planIndex].length-1) * 100;
                            progress += '%';
                            $('.progress-bar#' + data.id).css('width', progress);
                        });


                       
                        if (data.planId <= 0) {
                            return "Invalid Plan";
                        } else if (planIndex === 0) {
                        	moduleMultiselect = "Unavailable";
                        } else {
                            planName = plans[0][planIndex-1][0];
                            planId = plans[0][planIndex-1][1];
                            moduleMultiselect += '<optgroup value="'+planId+'" label="' + planName + '">';
                            for (var i = plans[planIndex].length-1; i > 0; i--) {
                                moduleMultiselect += '<option value="' + plans[planIndex][i][1] + '">' + plans[planIndex][i][0] + '</option>';
                            }
                            moduleMultiselect += '</optgroup>';
                            moduleMultiselect += '</select>';
                        }
                        

                        $('select[name=' + data.id + ']').multiselect({
                            onChange: function(option, checked, select) {
                                var val = $(option).val();
                                var status;
                                if (checked) {
                                    status = 2;
                                    $(".multiselect-container li.active").find('input[value=' + val + ']').siblings().addClass("crossOut");

                                } else {
                                    status = 1;
                                    $(".multiselect-container li").find('input[value=' + val + ']').siblings().removeClass("crossOut");
                                }

                                // Update Progress Bar
                                var comp = $('.module-multiselect[name=' + data.id + ']').siblings().find('li.active').length;
                                var progress = comp / (plans[planIndex].length-1) * 100;
                                progress += '%';
                                $('.progress-bar#' + data.id).css('width', progress);

                                // Update Data
                                var setData = {
                                    user: data.id,
                                    module: parseInt(val),
                                    isChecked: checked,
                                }

                                // Update Status
                                $.ajax({
                                    url: "http://localhost:8080/api/user/trainees/status",
                                    data: JSON.stringify(setData),
                                    type: "put",
                                    contentType: "application/json",
                                    dataType: "json",
                                    success: function(response) {
                                        console.log(response);
                                    },
                                    error: function(response) {
                                        console.log(response);
                                    }
                                });
                            }
                        });

                        return moduleMultiselect;
                    }
                },
                {
                    // Progress Bar
                    data: null,
                    render: function(data, type, row) {
                        return '<div class="progress" style="height: 5px;">' +
                            '<div class="progress-bar bg-green" id="' + data.id + '"role="progressbar" style="width: 0%;" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>' +
                            '</div>';
                    }
                },
                {
                    // Role Name
                    data: null,
                    render: function(data, type, row) {
                        return data.roleName.substring(data.roleName.indexOf("_") + 1);
                    }
                },
                {
                    // Date Created
                    data: null,
                    render: function(data, type, row) {
                        return moment.utc(data.createdAt).format("MM/DD/YYYY");
                    }
                },
            ],
            columnDefs: [{
                    targets: 0,
                    width: "5%"
                },
                {
                    targets: 1,
                    width: "60%"
                },
                {
                    targets: 2,
                    width: "10%"
                },
                {
                    targets: 3,
                    width: "10%"
                },
                {
                    targets: 4,
                    width: "10%"
                }
            ]
        });

        console.log(plans);
        var planDropdown = 	'<span class="container"><select class="form-control form-control-sm" id="planDropDown" style="width: 15rem">';
        if(myPlanId === "0") {
        	planDropdown += '<option selected="selected" value="0">All Plans</option>';
        } else {
        	planDropdown += '<option value="0">All Plans</option>';
        }
    	for(var c = 0; c < plans[0].length; c++) {
    		planDropdown += '<option ';
    		if(plans[0][c][1] === parseInt(myPlanId)) {
    			planDropdown += 'selected="selected"';
    		}
    		planDropdown += 'value="'+plans[0][c][1]+'">'+plans[0][c][0]+'</option>';
    	}
    	planDropdown +=	'</select>'+'</span>';
    	
        $('.dataTables_length').append(planDropdown);
        $("#planDropDown").change(function(){
        	var planUrl = "http://localhost:8080/api/user/trainees/"+ $(this).val();
        	
        	$("#userTable").dataTable().fnDestroy();
        	if($(this).val() === "0") {
        		userTable(defaultUrl,0);

        	} else {
        		userTable(planUrl,$(this).val());

        	}
        });
    }
    


});