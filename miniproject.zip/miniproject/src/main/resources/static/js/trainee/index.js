$(function(){

	var plan_id;
	var userId  = $("#user_id").text();
	var empty = '<div class="text-wrap ">' +
					'<h1>Please be guided.</h1>' +
					  	'<p>You will not be able to see your program plan unless you are assigned a plan or there are modules for your plan. If you see this message, it means you\'re not assigned to a plan or there are no modules for your plan yet.</p>' +
					'</div>';
	$.ajax({
		url : "http://localhost:8080/api/plans/" + userId,
		contentType : "application/json",
		type : "get"
	}).done(function(response){
		$.ajax({
		url: "http://localhost:8080/api/userplan",
		data: {
			user: userId,
			plan: response.id
		},
		contentType: 'application/json',
		type: 'get',
		success: function(response){
			if (response.length === 0){
				$("#indexContent").html(empty).addClass("example");
			}
			var cards = [];
						for(var i = 0 ; i < response.length; i++){
			var card_template = 
			'<div class="col-6 col-sm-4 col-lg-4 mb-6" >' +				
				'<div class="card card-modules" style="border-left-color:'+ colorize() +'">' +
					'<div class="card-body p-4 text-center">' +
								'<div class="text-right text-red">'+
                      				'<span class="tag '+ statusBadgeSetter(response[i].status).status  + '">'+ statusBadgeSetter(response[i].status).text +'</span>'+
                    			 '</div>'+
						' <div class="h1 mb-4" name="moduleName">' +
								response[i].name +
						'</div>' +
							'<p class="text-muted mb-4">' +
								response[i].description +
							'</p>' +
						'</div>' +
						'<div class="card-footer" >' +
							'<cite>Instructor : ' +
								response[i].instructor +
							'</cite></br>' +
							'<cite>Start Date : ' + 
								response[i].startDate +
							'</cite></br>' +
							'<cite>End Date : ' +
								response[i].endDate +
							'</cite>' +
						'</div>' +
					'</div>' +
				'</div>'+
			'</div>';
			cards.push(card_template);
		}
		$("#indexContent").append(cards);
		},
		error:function(response){
			$("#indexContent").html(empty).addClass("example");
		}
		
		
		});
	});	

	
	function statusBadgeSetter(status){
		switch(status){
		case 0: return {
			text: 'Not yet taken...',
			status: 'tag-gray-dark'
		}
			   break;
		case 1: return {
			text: 'Ongoing...',
			status: 'tag-azure'
		}
			   break;
		case 2: return {
			text: 'Completed',
			status: 'tag-green'
		}
			   break;
		    default: break;
		}
	}
	


	
	
	
	
});
	
