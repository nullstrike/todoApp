package com.enwan.miniproject.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailStatusDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.model.Role;
import com.enwan.miniproject.model.User;
import com.enwan.miniproject.model.UserPlan;
import com.enwan.miniproject.model.UserStatus;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PlanRepositoryTest {

	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void whenFindAllPlans_thenReturnListofViewPlanDto() {
		List<ViewPlanDto> plans = new ArrayList<>();
		plans.add(new ViewPlanDto(1, "Plan A - 2018"));
		plans.add(new ViewPlanDto(2, "Plan B - 2018"));
		plans.add(new ViewPlanDto(3, "Plan C - 2018"));
		plans.add(new ViewPlanDto(4, "Plan D - 2018"));
		plans.add(new ViewPlanDto(5, "Plan E - 2018"));
		plans.add(new ViewPlanDto(6, "Plan F - 2018"));
		
		for (ViewPlanDto viewPlanDto: plans) {
			Plan plan = new Plan();
			plan.setName(viewPlanDto.getName());
			entityManager.persist(plan);
			entityManager.flush();
		}
		
		assertEquals(planRepository.findAllPlans(), plans);
	}
	
	
	@Test
	public void whenFindAllBy_thenReturnListofViewPlanDetailDto() {
      
		Plan planA = new Plan();
        planA.setName("Plan A - 2018");
        entityManager.persist(planA);

        Module moduleA = new Module();
        moduleA.setName("CSS");
        moduleA.setDescription("CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.");
        entityManager.persist(moduleA);

        Module moduleB = new Module();
        moduleB.setName("HTML");
        moduleB.setDescription("Hypertext Markup Language is the standard markup language for creating web pages and web applications.");
        entityManager.persist(moduleB);

        PlanDetail planDetailA = new PlanDetail();
        planDetailA.setInstructor("Mozilla Firefox Foundation");
        planDetailA.setStartDate(LocalDate.now());
        planDetailA.setEndDate(LocalDate.now());
        planDetailA.setModule(moduleA);
        planDetailA.setPlan(planA);
        entityManager.persist(planDetailA);


        PlanDetail planDetailB = new PlanDetail();
        planDetailB.setInstructor("W3 Schools");
        planDetailB.setStartDate(LocalDate.now());
        planDetailB.setEndDate(LocalDate.now());
        planDetailB.setModule(moduleB);
        planDetailB.setPlan(planA);
        entityManager.persist(planDetailB);
        entityManager.flush();
        

        List<ViewPlanDetailDto> plandetails = new ArrayList<>();
        plandetails.add(new ViewPlanDetailDto(planDetailA.getId(), planDetailA.getModule().getName(), planDetailA.getModule().getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate()));
        plandetails.add(new ViewPlanDetailDto(planDetailB.getId(), planDetailB.getModule().getName(), planDetailB.getModule().getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate()));

      
        List<ViewPlanDetailDto> plandetail = new ArrayList<>();
        plandetail.add(new ViewPlanDetailDto(planDetailA.getId(), planDetailA.getModule().getName(), planDetailA.getModule().getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate()));
        plandetail.add(new ViewPlanDetailDto(planDetailB.getId(), planDetailB.getModule().getName(), planDetailB.getModule().getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate()));

        assertEquals(plandetails, planRepository.findAllBy(planA.getId()));
	}
	
	@Test
	public void whenGetAllModules_thenReturnListofViewPlanDetailStatusDto() {
		
		Role traineeRole = new Role();
		traineeRole.setRoleName("ROLE_TRAINEE");
		entityManager.persist(traineeRole);

		
		User userA = new User();
		userA.setFirstName("JOHN");
		userA.setMiddleName("DOE");
		userA.setLastName("ITASHIMASHITE");
		userA.setUsername("j.doe");
		userA.setPassword("Welcome18");
		userA.setRole(traineeRole);
		entityManager.persist(userA);
		
		Plan planA = new Plan();
        planA.setName("Plan A - 2018");
        entityManager.persist(planA);

        UserPlan userPlanA = new UserPlan();
        userPlanA.setPlan(planA);
        userPlanA.setUser(userA);
        entityManager.persist(userPlanA);
        
        Module moduleA = new Module();
        moduleA.setName("CSS");
        moduleA.setDescription("CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.");
        entityManager.persist(moduleA);

        Module moduleB = new Module();
        moduleB.setName("HTML");
        moduleB.setDescription("Hypertext Markup Language is the standard markup language for creating web pages and web applications.");
        entityManager.persist(moduleB);

        PlanDetail planDetailA = new PlanDetail();
        planDetailA.setInstructor("Mozilla Firefox Foundation");
        planDetailA.setStartDate(LocalDate.now());
        planDetailA.setEndDate(LocalDate.now());
        planDetailA.setModule(moduleA);
        planDetailA.setPlan(planA);
        entityManager.persist(planDetailA);


        PlanDetail planDetailB = new PlanDetail();
        planDetailB.setInstructor("W3 Schools");
        planDetailB.setStartDate(LocalDate.now());
        planDetailB.setEndDate(LocalDate.now());
        planDetailB.setModule(moduleB);
        planDetailB.setPlan(planA);
        entityManager.persist(planDetailB);
        
        UserStatus userStatusA = new UserStatus();
        userStatusA.setPlanDetail(planDetailA);
        userStatusA.setUserPlan(userPlanA);
        userStatusA.setStatus(0);
        entityManager.persist(userStatusA);
        
        UserStatus userStatusB = new UserStatus();
        userStatusB.setPlanDetail(planDetailB);
        userStatusB.setUserPlan(userPlanA);
        userStatusB.setStatus(0);
        entityManager.persist(userStatusB);
        entityManager.flush();
        
        List<ViewPlanDetailStatusDto> planDetailStatus = new ArrayList<>();
        planDetailStatus.add(new ViewPlanDetailStatusDto(planDetailA.getId(), moduleA.getName(), moduleA.getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate(), userStatusA.getStatus()));
        planDetailStatus.add(new ViewPlanDetailStatusDto(planDetailB.getId(), moduleB.getName(), moduleB.getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate(), userStatusB.getStatus()));
	
        assertEquals(planDetailStatus, planRepository.getAllModules(planA.getId(), userA.getId()));
        assertThat(planRepository.getAllModules(planA.getId(), userA.getId())).isEqualTo(planDetailStatus);
	}
	
}
