-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2018 at 12:24 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bootcamp_back`
--

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `ModuleId` int(11) NOT NULL,
  `ModuleName` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `PlanId` int(11) NOT NULL,
  `PlanName` varchar(255) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plandetail`
--

CREATE TABLE `plandetail` (
  `DetailId` int(11) NOT NULL,
  `PlanId` int(11) NOT NULL,
  `ModuleId` int(11) NOT NULL,
  `Instructor` varchar(255) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleId` int(11) NOT NULL,
  `RoleName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleId`, `RoleName`) VALUES
(1, 'ROLE_TRAINEE'),
(2, 'ROLE_FACILITATOR'),
(3, 'ROLE_ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `TaskId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Content` text NOT NULL,
  `TaskDate` date NOT NULL,
  `TaskType` enum('Done','Challenges','Todo') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(40) NOT NULL,
  `MiddleName` varchar(40) DEFAULT NULL,
  `LastName` varchar(40) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserId`, `FirstName`, `MiddleName`, `LastName`, `Username`, `Password`, `RoleId`, `CreatedAt`, `UpdatedAt`) VALUES
(1, 'N/A', 'N/A', 'N/A', 'admin', '$2a$10$VlsSYC5/P/51t/VB6PEmNOgdF6o.gvTVqW184raQNEN3C0BupeuQW', 3, '2018-06-28 07:11:18', '2018-06-28 07:11:18');

-- --------------------------------------------------------

--
-- Table structure for table `userplan`
--

CREATE TABLE `userplan` (
  `UserPlanId` int(11) NOT NULL,
  `PlanId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userstatus`
--

CREATE TABLE `userstatus` (
  `UserStatusId` int(11) NOT NULL,
  `UserPlanId` int(11) NOT NULL,
  `DetailId` int(11) NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`ModuleId`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`PlanId`);

--
-- Indexes for table `plandetail`
--
ALTER TABLE `plandetail`
  ADD PRIMARY KEY (`DetailId`),
  ADD KEY `FK_ModuleDetail` (`ModuleId`),
  ADD KEY `FK_Plan` (`PlanId`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleId`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`TaskId`),
  ADD KEY `FK_UserTask` (`UserId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `FK_UserRole` (`RoleId`);

--
-- Indexes for table `userplan`
--
ALTER TABLE `userplan`
  ADD PRIMARY KEY (`UserPlanId`),
  ADD KEY `FK_Plan` (`PlanId`),
  ADD KEY `FK_User` (`UserId`);

--
-- Indexes for table `userstatus`
--
ALTER TABLE `userstatus`
  ADD PRIMARY KEY (`UserStatusId`),
  ADD KEY `FK_UserPlanStatus` (`UserPlanId`),
  ADD KEY `FK_DetailStatus` (`DetailId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `ModuleId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plan`
--
ALTER TABLE `plan`
  MODIFY `PlanId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plandetail`
--
ALTER TABLE `plandetail`
  MODIFY `DetailId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `TaskId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userplan`
--
ALTER TABLE `userplan`
  MODIFY `UserPlanId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userstatus`
--
ALTER TABLE `userstatus`
  MODIFY `UserStatusId` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `plandetail`
--
ALTER TABLE `plandetail`
  ADD CONSTRAINT `FK_ModuleDetail` FOREIGN KEY (`ModuleId`) REFERENCES `module` (`ModuleId`),
  ADD CONSTRAINT `FK_Plan` FOREIGN KEY (`PlanId`) REFERENCES `plan` (`PlanId`);
--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `FK_UserTask` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserId`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_UserRole` FOREIGN KEY (`RoleId`) REFERENCES `role` (`RoleId`);

--
-- Constraints for table `userplan`
--
ALTER TABLE `userplan`
  ADD CONSTRAINT `FK_UsersPlan` FOREIGN KEY (`PlanId`) REFERENCES `plan` (`PlanId`),
  ADD CONSTRAINT `FK_User` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserId`);

--
-- Constraints for table `userstatus`
--
ALTER TABLE `userstatus`
  ADD CONSTRAINT `FK_DetailStatus` FOREIGN KEY (`DetailId`) REFERENCES `plandetail` (`DetailId`),
  ADD CONSTRAINT `FK_UserPlanStatus` FOREIGN KEY (`UserPlanId`) REFERENCES `userplan` (`UserPlanId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
