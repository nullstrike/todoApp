-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2018 at 11:27 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bootcamp`
--

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `ModuleID` int(11) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime NOT NULL,
  `Description` text NOT NULL,
  `ModuleName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`ModuleID`, `CreatedAt`, `UpdatedAt`, `Description`, `ModuleName`) VALUES
(4, '2018-06-25 10:51:59', '2018-06-25 10:51:59', 'View library by Facebook.', 'ReactJS'),
(5, '2018-06-25 10:52:18', '2018-06-25 10:52:18', 'Trending view framework.', 'VueJS'),
(6, '2018-06-25 10:52:40', '2018-06-25 10:52:40', 'Build cross-platform application using Javascript.', 'ReactNative'),
(7, '2018-06-25 15:31:10', '2018-06-25 15:31:10', 'VIEW', 'ReactJS');

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `PlanID` int(11) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime NOT NULL,
  `PlanName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`PlanID`, `CreatedAt`, `UpdatedAt`, `PlanName`) VALUES
(19, '2018-06-26 16:51:52', '2018-06-26 16:51:52', 'Batch G');

-- --------------------------------------------------------

--
-- Table structure for table `plandetail`
--

CREATE TABLE `plandetail` (
  `DetailID` int(11) NOT NULL,
  `EndDate` date NOT NULL,
  `Instructor` varchar(255) NOT NULL,
  `StartDate` date NOT NULL,
  `DetailStatus` tinyint(1) NOT NULL,
  `ModuleID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`) VALUES
(1, 'ROLE_TRAINEE'),
(2, 'ROLE_FACILITATOR'),
(3, 'ROLE_ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `TaskID` int(11) NOT NULL,
  `Content` text NOT NULL,
  `TaskDate` date NOT NULL,
  `TaskType` enum('Done','Challenges','Todo') NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `FirstName` varchar(40) NOT NULL,
  `LastName` varchar(40) NOT NULL,
  `MiddleName` varchar(40) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  `updatedAt` datetime NOT NULL,
  `Username` varchar(20) NOT NULL,
  `RoleID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `createdAt`, `FirstName`, `LastName`, `MiddleName`, `Password`, `updatedAt`, `Username`, `RoleID`) VALUES
(2, '2018-06-25 07:11:18', 'N/A', 'N/A', 'N/A', '$2a$10$VlsSYC5/P/51t/VB6PEmNOgdF6o.gvTVqW184raQNEN3C0BupeuQW', '2018-06-25 07:11:18', 'admin', 3),
(3, '2018-06-25 13:18:14', 'Jhefrey', 'Sajot', 'Lazaraga', '$2a$10$VKBoyomIYhv/2SewhVEb5O6hi6zzdfaXARCeIIJ03PTNCLgDZOdh.', '2018-06-25 13:18:14', 'j.sajot', 1),
(4, '2018-06-25 13:19:02', 'Dann', 'Astillero', 'JohnCena', '$2a$10$PpxNVc5cfpzzfGnBhsqMhuw6KiuJdPLXk7eCn4j/SIAEcOr7mJ64i', '2018-06-25 13:19:02', 'd.astillero', 2),
(5, '2018-06-25 17:24:00', 'Kyle', 'Montealto', 'Shem', '$2a$10$Trk11T6IW4o.d26jxT3NReM32f3shoExidAIOMiloji7tjCJ1Xob.', '2018-06-25 17:24:00', 'k.montealto', 1),
(6, '2018-06-25 17:38:14', 'Jay', 'Garrick', 's', '$2a$10$/gsgXKsZts0IW8VRoXOQAu6HCBsLVtxf8hjif5mYiCQHfhAOIWwRC', '2018-06-25 17:38:14', 'j.garrick', 1),
(7, '2018-06-25 17:38:57', 'Jason', 'Bourne', '', '$2a$10$5X42X/pjJX3Ur9yuWlWsXOkjdgZg2iVmE1pYXNFWcMxBwGEZmTmYq', '2018-06-25 17:38:57', 'j.bourne', 1),
(8, '2018-06-25 17:39:14', 'Barry', 'Allen', '', '$2a$10$La0ZexwrCMKW.cUgx5pXg.LKM1MfiwsPNxDXhaUFPmi9Qhzz/ExXe', '2018-06-25 17:39:14', 'b.allen', 1),
(9, '2018-06-25 17:40:17', 'Wally', 'West', '', '$2a$10$W564tInEWckuwDG1KeCHN.buD02h/LpZ/1CxSIhyxQUPsswTuNi9e', '2018-06-25 17:40:17', 'w.west', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userplan`
--

CREATE TABLE `userplan` (
  `UserPlanId` int(11) NOT NULL,
  `PlanId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userplan`
--

INSERT INTO `userplan` (`UserPlanId`, `PlanId`, `UserId`) VALUES
(22, 19, 5),
(23, 19, 8),
(24, 19, 6),
(25, 19, 9),
(26, 19, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`ModuleID`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`PlanID`);

--
-- Indexes for table `plandetail`
--
ALTER TABLE `plandetail`
  ADD PRIMARY KEY (`DetailID`),
  ADD KEY `FKpc6rx40s1qix1dxnulpknqehr` (`ModuleID`),
  ADD KEY `FKkthx1s0tfynptpdvr4u6xjwk0` (`PlanID`),
  ADD KEY `FK9chp1bpsandrf3kw1u66fepx7` (`UserID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`TaskID`),
  ADD KEY `FKfyvwdb1fibybx73djlpphdpg6` (`UserID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `FKngm7ewd8isdg4b7nk13ndkp7w` (`RoleID`);

--
-- Indexes for table `userplan`
--
ALTER TABLE `userplan`
  ADD PRIMARY KEY (`UserPlanId`),
  ADD KEY `FKdc3l2wdcs9hfmladsrfsu8xas` (`PlanId`),
  ADD KEY `FKj419w8d07vo5uhl9k9aaqks5p` (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `ModuleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `plan`
--
ALTER TABLE `plan`
  MODIFY `PlanID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `plandetail`
--
ALTER TABLE `plandetail`
  MODIFY `DetailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `TaskID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `userplan`
--
ALTER TABLE `userplan`
  MODIFY `UserPlanId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `plandetail`
--
ALTER TABLE `plandetail`
  ADD CONSTRAINT `FK9chp1bpsandrf3kw1u66fepx7` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`),
  ADD CONSTRAINT `FKkthx1s0tfynptpdvr4u6xjwk0` FOREIGN KEY (`PlanID`) REFERENCES `plan` (`PlanID`),
  ADD CONSTRAINT `FKpc6rx40s1qix1dxnulpknqehr` FOREIGN KEY (`ModuleID`) REFERENCES `module` (`ModuleID`);

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `FKfyvwdb1fibybx73djlpphdpg6` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FKngm7ewd8isdg4b7nk13ndkp7w` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);

--
-- Constraints for table `userplan`
--
ALTER TABLE `userplan`
  ADD CONSTRAINT `FKdc3l2wdcs9hfmladsrfsu8xas` FOREIGN KEY (`PlanId`) REFERENCES `plan` (`PlanID`),
  ADD CONSTRAINT `FKj419w8d07vo5uhl9k9aaqks5p` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
