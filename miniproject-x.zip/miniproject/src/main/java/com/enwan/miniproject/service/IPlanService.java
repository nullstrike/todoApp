package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.PlanDto;
import com.enwan.miniproject.dto.UpdatePlanDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Plan;


public interface IPlanService {
	
	
	
	Plan createPlan(PlanDto planDto);
	
	void deletePlanById(Integer id);
	
	void updatePlan (Integer id,PlanDto updatePlan);
	
	List<ViewPlanDto> getAllPlans();
	
	List<ViewPlanDetailDto> getPlanById(Integer planId);
	
}
