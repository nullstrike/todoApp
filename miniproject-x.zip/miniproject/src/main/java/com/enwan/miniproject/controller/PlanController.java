package com.enwan.miniproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.PlanDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.IPlanService;

@RestController
@RequestMapping("/api")
public class PlanController {

	private final IPlanService planService;

	@Autowired
	public PlanController(IPlanService planService) {
		this.planService = planService;
	}
	
	@GetMapping("/plan/{id}")
	public ResponseEntity<?> getPlanById(@PathVariable("id") Integer planId){
		List<ViewPlanDetailDto> planDetails = planService.getPlanById(planId);
		return new ResponseEntity<>(planDetails, HttpStatus.OK);
	}
	
	@GetMapping("/plans")
	public ResponseEntity<?> getAllPlans(){
		List<ViewPlanDto> plans = planService.getAllPlans();
		return new ResponseEntity<>(plans, HttpStatus.OK);
	}
	
	@PostMapping("/plan")
	public ResponseEntity<?> createPlan(@Valid @RequestBody PlanDto planDto){
		Integer planId = planService.createPlan(planDto).getId();
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created plan", planId ), HttpStatus.OK);
	}
	
	@PutMapping("/plan/{id}")
	public ResponseEntity<?> updatePlan(@PathVariable("id") Integer planId, @Valid @RequestBody PlanDto updatePlanDto){
		planService.updatePlan(planId, updatePlanDto);
		return new ResponseEntity<>("Successfully updated plan", HttpStatus.OK);
	}
	
	@DeleteMapping("/plan/{id}")
	public ResponseEntity<?> deletePlan(@PathVariable("id") Integer planId){
		planService.deletePlanById(planId);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully deleted plan"), HttpStatus.OK);
	}
	
	
	
	
	
}
