package com.enwan.miniproject.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ModuleDto {
	
	@NotBlank
	private String name;
	
	@NotBlank
	private String description;

	public ModuleDto(String name, String description) {
		this.name = name;
		this.description = description;
	}

	
}
