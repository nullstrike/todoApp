package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.model.Module;

@Repository
public interface ModuleRepository extends JpaRepository<Module, Integer> {
	
	@Query("select new com.enwan.miniproject.dto.ViewModuleDto(a.id,a.name,a.description) from Module a")
	List<ViewModuleDto> findAllModules();
	
	List<ViewModuleDto> findByNameContainingIgnoreCase(String name);

}
