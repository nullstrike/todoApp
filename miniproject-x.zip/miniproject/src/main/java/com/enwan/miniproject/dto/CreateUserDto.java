package com.enwan.miniproject.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class CreateUserDto {
	

	@Size(min = 2, max = 40, message = "Firstname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String firstName;
	
	private String middleName;

	@Size(min = 2, max = 40, message = "Lastname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String lastName;
	
	@Size(max = 20, message = "Username must not more than 20 characters")
	private String username;
	
	@NotNull
	private Integer role;

	public CreateUserDto(String firstName, String middleName,  String lastName, String username, Integer role) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.username = username;
		this.role = role;
	}
	
	

}
