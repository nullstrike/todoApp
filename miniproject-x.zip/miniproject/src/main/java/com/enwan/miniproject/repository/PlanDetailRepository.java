package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.model.PlanDetail;

@Repository
public interface PlanDetailRepository extends JpaRepository<PlanDetail, Integer> {
	
	@Query(" select new com.enwan.miniproject.dto.ViewPlanDetailDto(a.plan.id, a.module.id, a.id, b.name, b.description, a.instructor, a.startDate, a.endDate, a.status) from PlanDetail a join a.module b where a.plan.id = :plan_id ")
	List<ViewPlanDetailDto> findAllBy(@Param("plan_id") Integer plan_id);
	
}
