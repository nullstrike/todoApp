package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UpdatePlanDetailDto {
	
	private Integer moduleId;

    private String instructor;
    
    private Date startDate;
    
    private Date endDate;
    
    private Integer status;

	public UpdatePlanDetailDto(Integer moduleId, Integer userId, String instructor, Date startDate, Date endDate,
			Integer status) {
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
	}

    
    
    
}
