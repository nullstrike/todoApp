package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.repository.ModuleRepository;
import com.enwan.miniproject.repository.PlanDetailRepository;
import com.enwan.miniproject.repository.PlanRepository;
import com.enwan.miniproject.repository.UserRepository;

@Service
public class PlanDetailService implements IPlanDetailService {


	private final PlanDetailRepository planDetailRepository;
	
	private final ModuleRepository moduleRepository;

	private final PlanRepository planRepository;
	
	private final UserRepository userRepository;
	
	private static final int DEFAULT_STATUS = 0;
	
	@Autowired
	public PlanDetailService(PlanDetailRepository planDetailRepository, ModuleRepository moduleRepository,
			PlanRepository planRepository, UserRepository userRepository) {
		this.planDetailRepository = planDetailRepository;
		this.moduleRepository = moduleRepository;
		this.planRepository = planRepository;
		this.userRepository = userRepository;
	}

	@Override
	public void createPlanDetail(CreatePlanDetailDto createPlanDetail) {
		PlanDetail planDetail = new PlanDetail();
		Module module = moduleRepository.findById(createPlanDetail.getModuleId()).get();
		Plan plan = planRepository.findById(createPlanDetail.getPlanId()).orElseThrow(() -> new RuntimeException("No plan found"));
		
		planDetail.setEndDate(createPlanDetail.getEndDate());
		planDetail.setInstructor(createPlanDetail.getInstructor());
		planDetail.setStartDate(createPlanDetail.getStartDate());
		planDetail.setPlan(plan);
		planDetail.setModule(module);
		planDetail.setStatus(DEFAULT_STATUS);
		
		planDetailRepository.save(planDetail);
	}

	@Override
	public void updatePlanDetail(Integer planId, UpdatePlanDetailDto updatePlanDetail) {
		PlanDetail planDetail = planDetailRepository.findById(planId).get();
		Module module = moduleRepository.findById(updatePlanDetail.getModuleId()).get();
		
		planDetail.setModule(module);
		planDetail.setEndDate(updatePlanDetail.getEndDate());
		planDetail.setInstructor(updatePlanDetail.getInstructor());
		planDetail.setStartDate(updatePlanDetail.getStartDate());
		planDetail.setStatus(updatePlanDetail.getStatus());
				
		planDetailRepository.save(planDetail);

	}

	@Override
	public void deletePlanDetailById(Integer id) {
		PlanDetail planDetail = planDetailRepository.findById(id).get();
		planDetailRepository.delete(planDetail);
	}

	@Override
	public List<ViewPlanDetailDto> findAllPlan(Integer id) {
		return planDetailRepository.findAllBy(id);
	}

}
