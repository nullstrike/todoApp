package com.enwan.miniproject.dto;

import javax.persistence.Transient;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.enwan.miniproject.constraint.PasswordMatches;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@PasswordMatches
public class ChangePasswordDto {

	private String username;
	
	@NotNull(message = "Current password field should not be null")
	@NotEmpty(message = "Current password field should not be empty")
	private String currentPassword;
	
	@NotNull(message = "New password field should not be null")
	@NotEmpty(message = "New password field should not be empty")
	@Size(min = 8, max = 15, message = "New password should be 8 to 15 characters. ")
	private String newPassword;
	
	@NotNull(message = "Confirm password field should not be null")
	@NotEmpty(message = "Confirm password field should not be empty")
	@Transient
	private String confirmPassword;

	

}
