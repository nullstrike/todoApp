package com.enwan.miniproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enwan.miniproject.dto.ModuleDto;
import com.enwan.miniproject.dto.ViewModuleDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.repository.ModuleRepository;

@Service
public class ModuleService implements IModuleService {

	@Autowired
	private ModuleRepository moduleRepository;
	
	
	@Override
	public Module createModule(ModuleDto createModule) {
		Module module = new Module();
		module.setName(createModule.getName());
		module.setDescription(createModule.getDescription());
		return moduleRepository.save(module);
	}

	@Override
	public Module updateModule(Integer id, ModuleDto updateModule) {
		Module module = moduleRepository.findById(id).get();
		module.setName(updateModule.getName());
		module.setDescription(updateModule.getDescription());
		return moduleRepository.save(module);
	}

	@Override
	public void deleteModuleById(Integer id) {
		Module module = moduleRepository.findById(id).orElseThrow(() -> new RuntimeException("No module found."));
		moduleRepository.delete(module);
	}

	@Override
	public List<ViewModuleDto> findAllModule() {
		return moduleRepository.findAllModules();
	}

	@Override
	public List<ViewModuleDto> findModuleByName(String name) {
		List<ViewModuleDto> module = moduleRepository.findByNameContainingIgnoreCase(name);
		return module;
	}

}
