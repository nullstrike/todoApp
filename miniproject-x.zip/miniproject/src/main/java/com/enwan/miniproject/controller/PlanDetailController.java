package com.enwan.miniproject.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.CreatePlanDetailDto;
import com.enwan.miniproject.dto.UpdatePlanDetailDto;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.IPlanDetailService;

@RestController
@RequestMapping("/api")
public class PlanDetailController {

	private final IPlanDetailService planDetailService;
	
	@Autowired
	public PlanDetailController(IPlanDetailService planDetailService) {
		this.planDetailService = planDetailService;
	}


	@PostMapping("/plandetail")
	public ResponseEntity<?> createPlanDetail(@Valid @RequestBody CreatePlanDetailDto planDetailDto ){
		planDetailService.createPlanDetail(planDetailDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created plan detail. "), HttpStatus.OK);
	}
	
	@PutMapping("/plandetail/{id}")
	public ResponseEntity<?> updatePlanDetail(@PathVariable("id") Integer planId, @Valid @RequestBody UpdatePlanDetailDto planDetailDto){
		planDetailService.updatePlanDetail(planId, planDetailDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully updated plan detail. "), HttpStatus.OK);
	}
	
	@DeleteMapping("/plandetail/{id}")
	public ResponseEntity<?> deletePlanDetail(@PathVariable("id") Integer planId){
		planDetailService.deletePlanDetailById(planId);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully deleted plan detail. "), HttpStatus.OK);
	}
}
