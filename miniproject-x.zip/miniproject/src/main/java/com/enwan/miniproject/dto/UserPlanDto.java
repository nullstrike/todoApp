package com.enwan.miniproject.dto;

import lombok.Data;

@Data
public class UserPlanDto {
	
	private Integer id;
	
	private String text;

	public UserPlanDto(Integer id, String text) {
		this.id = id;
		this.text = text;
	}
	
	
}
