$(function () {
	

	//performs logout action
	$("#logOut").on("click", function() {
		$("#logoutForm").submit();
	});
	
	//performs change password action
	$("#changePasswordButton").on('click', function(event) {
		event.preventDefault();
		var form = $('#changePasswordForm');
		$.ajax({
			url: "http://localhost:8080/api/users",
			type: "patch",
			contentType: "application/json",
			dataType: "json",
			data: transformToJSON(form),
			success: function(response){
				$("#changePasswordModal").modal('hide');
				swal("Updating password", response.message, "success");
			},
			error: function(errors){
				var fieldErrors = errors.responseJSON.errors;
				for (var fieldError in fieldErrors){
					if (fieldError === 'changePasswordDto'){
						$('input[name=newPassword], input[name=confirmPassword]').removeClass('is-valid').addClass('is-invalid').next().next().html(fieldErrors[fieldError]);
					}
					$('input[name=' + fieldError + ']').removeClass('is-valid').addClass('is-invalid').next().next().html(fieldErrors[fieldError]);
				}
			}
		});
	});
	
	$('#changePasswordForm input').on("blur",function(){

		if( $(this).val().length >= 8 ) {
			 $(this).removeClass('is-invalid').addClass('is-valid');
		} else {
			 $(this).removeClass("is-valid").addClass('is-invalid');
	    }
   
	});
	
	$("#changePasswordModal").on("hidden.bs.modal", function(e){
		$(this).find("input").each(function(index, input){
			var element = $(input);
			if (element.attr("type") === "hidden"){
				return;
			}
			$(input).val("").removeClass("is-valid is-invalid");
			
		});
	});
});

function transformToJSON(form){
	var data = {};
	
	form.serializeArray().map(function(input){
		data[input.name] = input.value;
	});
	
	return JSON.stringify(data);
}