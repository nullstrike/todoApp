   $(function() {

	   var empty_template = '<tr class="task_placeholder header">' +
		'<td>Nothing to show here...</td>'	+
			'</tr>';
        $('#calendar').fullCalendar({
        	selectable: true,
        	dayClick: function(date){
        		alert(date.format());
        	}
        });
        $('#add_task').on('click', function() {
			var task = $("textarea[name=task]");
			var type  = $("select").val();
			var template = '<tr>' +
            					'<td class="" style="width:75%" data-task-type="'+ type + '">' + task.val() + '</td>' +
            					'<td class="" style="width:25%">' + '<a href="javascript:void(0)" class="btn btn-sm task_edit"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>' +
            					'<a href="javascript:void(0)" class="btn btn-sm task_save" style="display:none;"><i class="dropdown-icon fe fe-save"></i> Save </a>' +
        						
            					'<a href="javascript:void(0)" class="btn btn-sm  task_delete text-danger"><i class="dropdown-icon fe fe-trash" ></i> Delete </a>' + '</td>' + 
        				
           					'</tr>';
           					
           	
           					
           	if (!$.trim($("#task").val())) {
				swal("Adding task failed.", "Task should not be empty.", "error");
			} else {
				if (type === "Done"){
					$("#complete_list").append(template).find("tr.task_placeholder").remove();
				}
				
				if (type === "Challenges") {
					$("#challenge_list").append(template).find("tr.task_placeholder").remove();
				}
				
				if (type === "Todo") {
					$("#todo_list").append(template).find("tr.task_placeholder").remove();
				}
				task.val("");
			} 
		});
        
        $("table tbody").on("click", ".task_edit", function() {
        	var val = $(this).closest("tr").find("td:first").text();
        	$(this).closest("tr").find("td:first").html("<textarea class='form-control' autocomplete='off'>" + val + "</textarea>");
        	$(this).hide();
        	$(this).closest("tr").find(".task_save").show();
        });
        
        $("table tbody").on("click", ".task_save", function () {
        	var parent = $(this).closest("tr");
        	var val = parent.find("textarea").val();
        	parent.find("td:first").html(val);
        	$(this).hide();
        	parent.find(".task_edit").show();
        });
        
        $("table tbody").on("click", ".task_delete", function() {
        	var temp = $(this).closest("tr").parent();
        	var row_count = $(this).closest("tr").parent();
        	$(this).closest("tr").remove();
        	if (row_count[0].children.length === 0){
        		temp.append(empty_template);
        	}
        });
        
        $("#addReportButton").on("click", function() {
     	   var user_id = parseInt($("#user_id").text());
    	   var today = new Date().toLocaleDateString();
           var data = [];

        	$("#complete_list tbody > tr, #challenge_list tbody > tr , #todo_list tbody > tr").each(function(index, element) {
        		var current = $(element);
        		var dataContainer = {
        				userId: user_id
        		};
    			var content = $.trim(current.find("td:nth-child(1)").text());
    			var type = current.find("td:nth-child(1)").data('task-type');
    			
    			
    			if (current.attr('class') === undefined){
    				dataContainer["text"] = current.find("td:nth-child(1)").text();
            		dataContainer["type"] = current.find("td:nth-child(1)").data('task-type');
            		data.push(dataContainer);
    			}
    			
        	});
        	
 /*       	$.ajax({
        		url: "http://localhost:8080/api/task",
        		data: JSON.stringify(data),
        		type: "post",
        		dataType: "json",
        		contentType: "application/json",
        		success: function(response){
        			var successResponse = response.responseJSON;
        			swal("Daily report creation", response.message, "success");
        			resetTables();
        			$("#task_modal").modal("hide");
        		},
        		error: function(response){
        			var errorResponse = response.responseJSON;
        			swal("Daily report creation failed!", errorResponse.message, "error");
        		}
        	});*/
        	
        });
        
        function resetTables(){
        	var placeholder = '<tr class="task_placeholder header"> ' + 
                    						'<td>Nothing to show here...</td>' +	
                   						'</tr>';
        	
        	$("#complete_list, #challenge_list, #todo_list").find("tbody").html(placeholder);
        }
        
        $("#task_modal").on("hidden.bs.modal", function() {
        	resetTables();
        });
        
});