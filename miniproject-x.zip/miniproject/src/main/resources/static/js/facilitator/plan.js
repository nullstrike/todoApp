$(document).ready(function(){
	var planName = $("input[name=planName]");
	var planId;
	var module_id, plan_id;
	var instructor = $("input[name=instructor]");
	var startDate = $("input[name=startDate]");
	var endDate = $("input[name=endDate]");
	var user_id = parseInt($("#user_id").text());
	$('input[name=startDate], input[name=endDate]').datepicker({
		format : "yyyy-dd-mm"
	});
	
	  $.contextMenu({
          selector: '.context-menu-one', 
          items: {
              "edit": {
            	  		name: "Edit Plan", 
            	  		icon: "edit",
            	  		callback: function(key, options){
            	  			var planText = $(options.$trigger[0]).text();
            	  			planId = $(options.$trigger[0]).data('id');
            	  			var userPlan = $("#trainee_list");
            	  			
            	  			$.ajax({
            	  			    type: 'GET',
            	  			    url: 'http://localhost:8080/api/user/plan/' + planId
            	  			}).then(function (response) {
	            	  			var list = [];
	            	  			for (var data in response){
	            	  				var template = "<li class='list-group-item' data-id='"+ response[data].id +"'>" + response[data].text +
	            	  				"<span class='float-right'><span class='btn btn-sm text-danger remove-plan'>" +
			                            "<span class='fas fa-trash fa-lg'></span></span></span></li>";
	            	  				list.push(template);
	            	  			}
	            	  			$("#planName").val(planText);
	            	  		
	            	  			userPlan.html(list);
	            	  			
            	  			});
            	  			
            	  			$("#planModal .modal-title").text("Update Plan");
            	  			$("#savePlan").hide();
            	  			$("#trainee_list_wrapper").show();
            	  			$("#updatePlan").prop("hidden", false);
            	  			$("#planModal").modal('show');
            	  		}},
              "delete": {name: "Delete Plan", icon: "delete", callback: function(key, options){
  	  			var id = options.$trigger[0].dataset.id
		  	  		swal({
		  	  		  title: 'Are you sure?',
		  	  		  text: "You won't be able to revert this!",
		  	  		  type: 'warning',
		  	  		  showCancelButton: true,
		  	  		  cancelButtonColor: '#3085d6',
		  	  		  confirmButtonColor: '#d33',
		  	  		  toast: true,
		  	  		  target: $("#planModal"),
		  	  		  backdrop: false,
		  	  		  confirmButtonText: 'Yes, delete it!'
		  	  		}).then((result) => {
		  	  		  if (result.value) {
		  	  			deletePlan(id);
		  	  		    $(this).fadeOut(1000);
		  	  			  swal({
			  	  			  title: 'Deleted!',
	  			  	  		  text: "Program plan has been deleted.",
	  			  	  		  type: 'success',
	  			  	  		  backdrop: false
		  	  			  })
		  	  		  }
		  	  		})
	  			}}
          }
      });
	
	$("#trainee_list").on("click", ".remove-plan", function(e){
		var id = $(this).closest("li").data("id");
  		swal({
  	  		  title: 'Are you sure?',
  	  		  text: "You won't be able to revert this!",
  	  		  type: 'warning',
  	  		  showCancelButton: true,
  	  		  cancelButtonColor: '#3085d6',
  	  		  confirmButtonColor: '#d33',
  	  		  target: $("#planModal"),
  	  		  backdrop: false,
  	  		  confirmButtonText: 'Remove trainee'
  	  		}).then((result) => {
  	  		  if (result.value) {
  	  			  $(this).closest("li").fadeOut(1000);
  	  			removeUserFromPlan(id);
  	  			  swal(
  	  		      'Remove!',
  	  		      'Trainee has been removed from the plan. ',
  	  		      'success'
  	  		    )
  	  		  }
  	  		})
		
  		
  		
	})
	
	function removeUserFromPlan(id){
		$.ajax({
  			url : "http://localhost:8080/api/user/plan/" + id,
  			type : "delete",
  			dataType : "json",
  			contentType : "application/json",
  			success : function(response) {
  			},
  			error : function(response) {
  				console.log(response);
  			}
  		})
	}
	
    function deletePlan(id){
    	  $.ajax({
  			url : "http://localhost:8080/api/plan/" + id,
  			type : "delete",
  			dataType : "json",
  			contentType : "application/json",
  			success : function(response) {
  			},
  			error : function(response) {
  				console.log(response);
  			}
  		})
      }  
      
	$('.select-trainees').select2({
		  dropdownParent: $('#planModal'),
		  minimumInputLength: 2,
		  placeholder: "Add trainees...",
		  ajax: {
		    url: 'http://localhost:8080/api/user/find',
		    data: function(params){
		    	var query = {
		    		name: params.term
		    	}
		    	return query;
		    },
		    processResults: function (data) {
		    	  return {
		    	    results: data
		    	  }
		    }
	
		  }
		});

	$.ajax({
			url : "http://localhost:8080/api/plans",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var plan_template = '<button type="button" class="btn btn-pill btn-info plans context-menu-one pb-2" data-id="'+ response[i].planID +'" style="width:200px">'
						+ response[i].name + '</button>';
					$("#planContent").append(plan_template);
				}
			}
	});
	
	$("#savePlan").on("click",function(event) {
		$.ajax({
			url : "http://localhost:8080/api/plan",
			data : JSON.stringify({
					"name" :  planName.val(),
					"trainees": $(".select-trainees").select2("val")
					}),
			type : "post",
			dataType : "json",
			contentType : "application/json",	
			success : function(response) {
				var plan_template = '<button type="button" class="btn btn-pill btn-info plans context-menu-one pb-2" data-id="'+ response.id +'" style="width:200px">'
				+ planName.val() + '</button>';
				$("#planContent").append(plan_template);
				$("#planModal").modal('hide');
				planName.val("");				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	
	$("div.col-3").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/plan/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				swal("success", "deleted", "success" );
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	
	$("#btnAddPlan").on("click", function(){
		$("#planModal .modal-title").text("Add program plan");
		$("#savePlan").show();
		$("#trainee_list_wrapper").hide();
		$("#updatePlan").prop("hidden", true);
	});

	$("#updatePlan").on("click", function() {
		$.ajax({
			url : "http://localhost:8080/api/plan/" + planId,
			data : JSON.stringify({
					"name" :  planName.val(),
					"trainees": $(".select-trainees").select2("val")
					}),
			type : "put",
			dataType : "text",
			contentType : "application/json",
			success: function(response){
				
				swal({
					title:"Update plan", 
					text: "Successfully updated plan", 
					type: "success",
					backdrop: false,
					target: $("#planModal")
				});
				
				$("#planModal").modal('hide');
			}
		});
	});
	
	$("#btnRegister").on("click",function(event){
		console.log(module_id);
		var formData = {
				"moduleId" : module_id,
				"planId": plan_id,
				"instructor" : instructor.val(),
				"startDate" : startDate.val(),
				"endDate" : endDate.val(),
				"userId" : user_id
		};
		$.ajax({
			url: "http://localhost:8080/api/plandetail",
			type: "post",
			dataType: "json",
			data: JSON.stringify(formData),
			contentType: "application/json",
			success: function(response){
				
				console.log(module_id);
				$("#createProgramPlan").modal("hide");
				
			},
			error: function(response){
				console.log(module_id);
				console.log(response);
			}
		})
	});
	
	var plan = function() {
		$.ajax({
			url : "http://localhost:8080/api/planDetail/createPlanDetail",
			contentType : "application/json",
			type : "get",
			success : function(response) {
				for(var i = 0 ; i < response.length; i++){
					var table_template = '<td class="text-center"><div class="avatar d-block">' 
										 +response[i].name.charAt(0)+'</td><td>'+response[i].name+'</td><td>'
										 +response[i].description+'</td><td>'
										 +response[i].instructor+'</td><td>'
										 +response[i].startDate+'</td><td>'
										 +response[i].endDate+'</td><td class="text-center"><div class="item-action dropdown"><a href="javascript:void(0)" data-toggle="dropdown" class="icon">'
										 +'<i class="fe fe-more-vertical"></i></a><div class="dropdown-menu dropdown-menu-right">'
										 +'<div class="dropdown-menu dropdown-menu-right">'
										 +'<a href="javascript:void(0)" class="dropdown-item" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'"><i class="dropdown-icon fe fe-edit-2"></i> Edit</a>'
										 +'<a href="javascript:void(0)" class="dropdown-item" data-id="'+response[i].detailId+'"><i class="dropdown-icon fe fe-trash"></i> Delete</a>'
										 +'</div></div></td></tr>';
				$("#detailTable").append(table_template);
				}
			}
		});
	} 
	
	$("body").on("click", ".plans", function(){
		$("#createProgramButton").attr("hidden", false);
		plan_id = $(this).data('id');
		$.ajax({
			url: 'http://localhost:8080/api/plan/' + plan_id,
			contentType: 'application/json',
			success:function(response){
				if (response.length === 0){
					$("#detailTable tbody").html("<tr class='placeholder text-center'><td colspan='7'>No modules found...</td></tr>");
				} else {
					var data_template = [];
					for(var i=0;i<response.length;i++){
						
					var table_template = '<tr data-detail-id="' + response[i].detailId +'" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'">'
					+'<td class="text-center">'
					+'<div class="avatar d-block">'
						+response[i].name.charAt(0)
						+'</div>'
						+'</td>'
				+'<td>'
				+'<div>'+response[i].name+'</div></td>'
				+'<td>'+response[i].description+'</td>'
				+'<td>'+response[i].instructor+'</td>'
				+'<td>'+response[i].startDate+'</td>'
				+'<td>'+response[i].endDate+'</td>'
				+'<td>'
				+'<div class="item-action dropdown">'
				
				+'<a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i class="fe fe-more-vertical"></i></a>'
				+'<div class="dropdown-menu dropdown-menu-right">'
				+'<a href="javascript:void(0)" class="dropdown-item edit" data-plan-id="'+response[i].planId+'" data-module-id="'+response[i].moduleId+'"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>'
				+'<a href="javascript:void(0)" class="dropdown-item delete" data-id="'+response[i].detailId+'"><i class="dropdown-icon fe fe-message-square"></i> Delete</a>'
				+'</div></div></td></tr>';
					data_template.push(table_template);
				
					}
					$("#detailTable tbody").html(data_template);
					
				}
				}

		});
	});
	
	$("table tbody").on("click", ".delete", function(event){
		var id = $(this).data('id');
		$(this).parent().parent().parent().parent().fadeOut(1000);
		$.ajax({
			url : "http://localhost:8080/api/planDetail/" + id,
			type : "delete",
			dataType : "json",
			contentType : "application/json",
			success : function(response) {
				
			},
			error : function(response) {
				console.log(response);
			}
		})
	});
	$("body").on("click", ".edit", function(event){
		
		var instructor = $(this).parent().parent().parent().prev().prev().prev().text();
		var startDate = $(this).parent().parent().parent().prev().prev().text();
		var endDate = $(this).parent().parent().parent().prev().text();
		
		
		$(this).parent().parent().parent().prev().prev().prev().html("<input type='text' class='form-control' value='"+ instructor +"'>");
		$('input[name=startDate]').datepicker({
			format : "yyyy-dd-mm"
		});
		
		var endDateJS = $("<input type='text' name='endDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000'  value='"+ endDate +"'>").datepicker({format : "yyyy-dd-mm"});
		var startDateJS = $("<input type='text'  name='startDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000' value='"+ startDate +"'>").datepicker({format: "yyyy-dd-mm"});
		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		
		$(this).parent().parent().parent().prev().prev().html(startDateJS);
		$(this).parent().parent().parent().prev().html(endDateJS);
		$(this).parent().parent().html("").append(btnSave);
	});
	
	
	$("body").on("click", "#btnSave", function(event){
		var id = $(this).parent().parent().parent().data('id');
		var instructor = $(this).parent().parent().parent().prev().prev().prev().find("input").val();
		var startDate = $(this).parent().parent().parent().prev().prev().find("input").val();
		var endDate = $(this).parent().parent().parent().prev().find("input").val();
		var endDateJS = $("<input type='text' name='endDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000'  value='"+ endDate +"'>").datepicker({format : "yyyy-dd-mm"});
		var startDateJS = $("<input type='text'  name='startDate' class='form-control' data-mask='00/00/0000' data-mask-clearifnotmatch='true' placeholder='00/00/0000' value='"+ startDate +"'>").datepicker({format: "yyyy-dd-mm"});
		var btnSave =$("<button type= 'button' class='btn btn-warning btn-sm' id='btnSave'><span class='fe fe-check'></span></button>");
		var dropdown_template =$("<div class='item-action dropdown'>" 
					+"<a href='javascript:void(0)' data-toggle='dropdown' class='icon'>"
					+"<i class='fe fe-more-vertical'></i></a><div class='dropdown-menu dropdown-menu-right'>"
					+"<a href='javascript:void(0)' class='dropdown-item edit' data-plan-id='"+$(this).parent().parent().parent().find('tr')+
					+"' data-module-id='"+$(this).parent().parent().parent().find('tr')+"><i class='dropdown-icon fe fe-edit-2'></i> Edit </a><a href='javascript:void(0)' class='dropdown-item delete' data-id='"
					+$(this).parent().parent().parent().find('tr') +"'><i class='dropdown-icon fe fe-message-square'></i> Delete</a></div></div></td></tr>");


		$(this).parent().parent().parent().prev().prev().prev().html(instructor);
		$(this).parent().parent().parent().prev().prev().html(startDateJS);
		$(this).parent().parent().parent().prev().html(endDateJS);
		$(this).parent().parent().html("").append(dropdown_template);
		
		
		var setData = {
				id : id,
				instructor : instructor,
				startDate : startDate,
				endDate : endDate
		};
		$.ajax({
			url: "http://localhost:8080/api/planDetail/" + id,
			data: JSON.stringify(setData),
			type: "patch",
			contentType: "application/json",
			dataType: "json",
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log(response);
			}
		});
	});
	
	$( "#module" ).autocomplete({
        		source: function(request, response){
	        		$.ajax({
	                        url: "http://localhost:8080/api/module",
	                        data: {
	                        		name: request.term
	                        },
	                        dataType: "json",
	                        success: function(data){
	                              response ($.map(data, function(item){
	                                 return {
	                                	 		id: item.id,
	                            	 			label: item.name,
	                            	 			value: item.name,
	                            	 			description: item.description
	                                 		};
	                              })); 
	                        }
	        		});
        	  },
        	  autoFocus: true,
        	  minLength: 2,
        	  change: function(event, ui){
        		  var element = $(event.target);
		          if (ui.item === null){
		              element.val("");
		          }
        	  },
        	  select: function (event, ui) {        
        		  module_id = ui.item.id;
        		  return true;
        	  },
        	  messages: {
        		  noResults: function(count) {
        			  $("#tags").attr("placeholder", "There were " + count + " matches");
        		  },
        	  }  
     }).autocomplete( "instance" )._renderItem = function( ul, item ) {
          return $( "<li>" )
            .append( "<div>" + '<span data-id="' + item.id  + '" class="avatar avatar-' + colorize() + '">' + item.label.substring(0, 1) + '</span>' + "<strong class='result-icon'>" + " " +item.label + "</strong>" + "<br>" + item.description + "</div>" )
            .appendTo( ul );
        };
        
    $("#module").autocomplete("option", "appendTo", "#planDetailForm");
    
    $("#planModal").on("hidden.bs.modal", function(){
    	planName.val("");
    	$('.select-trainees').val('').trigger('change');
    });
      
});
		
	function colorize()	{
		var colors = [
		       "blue",
		       "azure",
		       "indigo",
		       "purple",
		       "pink",
		       "red",
		       "orange",
		       "yellow",
		       "lime",
		       "green",
		       "teal",
		       "cyan",
		       "gray",
		       "gray-dark"
		];
		
		return colors[parseInt((Math.random() * colors.length) + 1)];
	}



