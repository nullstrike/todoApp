package com.enwan.miniproject.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.assertj.core.api.ListAssert;
import org.h2.util.New;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.enwan.miniproject.dto.ViewPlanDetailDto;
import com.enwan.miniproject.dto.ViewPlanDto;
import com.enwan.miniproject.model.Module;
import com.enwan.miniproject.model.Plan;
import com.enwan.miniproject.model.PlanDetail;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PlanRepositoryTest {

	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void whenFindAllPlans_thenReturnListofViewPlanDto() {
		List<ViewPlanDto> plans = new ArrayList<>();
		plans.add(new ViewPlanDto(1, "Plan A - 2018"));
		plans.add(new ViewPlanDto(2, "Plan B - 2018"));
		plans.add(new ViewPlanDto(3, "Plan C - 2018"));
		plans.add(new ViewPlanDto(4, "Plan D - 2018"));
		plans.add(new ViewPlanDto(5, "Plan E - 2018"));
		plans.add(new ViewPlanDto(6, "Plan F - 2018"));
		
		for (ViewPlanDto viewPlanDto: plans) {
			Plan plan = new Plan();
			plan.setName(viewPlanDto.getName());
			entityManager.persist(plan);
			entityManager.flush();
		}
		
		assertEquals(planRepository.findAllPlans(), plans);
	}
	
	public void equalityPlanDetailDto() {
        java.sql.Date startDate = new java.sql.Date(new Date().getTime());
        java.sql.Date endDate = new java.sql.Date(new Date().getTime());
        Plan planA = new Plan();
        planA.setName("Plan A - 2018");
        entityManager.persist(planA);
        entityManager.flush();
        Module moduleA = new Module();
        moduleA.setName("CSS");
        moduleA.setDescription("CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.");
        entityManager.persist(moduleA);
        entityManager.flush();
        Module moduleB = new Module();
        moduleB.setName("HTML");
        moduleB.setDescription("Hypertext Markup Language is the standard markup language for creating web pages and web applications.");
        entityManager.persist(moduleB);
        entityManager.flush();
        PlanDetail planDetailA = new PlanDetail();
        planDetailA.setInstructor("Mozilla Firefox Foundation");
        planDetailA.setStartDate(startDate);
        planDetailA.setEndDate(endDate);
        planDetailA.setModule(moduleA);
        planDetailA.setPlan(planA);
        entityManager.persist(planDetailA);
        entityManager.flush();

        PlanDetail planDetailB = new PlanDetail();
        planDetailB.setInstructor("W3 Schools");
        planDetailB.setStartDate(startDate);
        planDetailB.setEndDate(endDate);
        planDetailB.setModule(moduleB);
        planDetailB.setPlan(planA);
        entityManager.persist(planDetailB);
        entityManager.flush();
        

        List<ViewPlanDetailDto> plandetails = new ArrayList<>();
        plandetails.add(new ViewPlanDetailDto(planDetailA.getId(), planDetailA.getModule().getName(), planDetailA.getModule().getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate()));
        plandetails.add(new ViewPlanDetailDto(planDetailB.getId(), planDetailB.getModule().getName(), planDetailB.getModule().getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate()));
        
        List<ViewPlanDetailDto> plandetailss = new ArrayList<>();
        plandetails.add(new ViewPlanDetailDto(planDetailA.getId(), planDetailA.getModule().getName(), planDetailA.getModule().getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate()));
        plandetails.add(new ViewPlanDetailDto(planDetailB.getId(), planDetailB.getModule().getName(), planDetailB.getModule().getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate()));
        
        List<ViewPlanDetailDto> planAs = new ArrayList<>();
        planAs.add(new ViewPlanDetailDto(1, "A", "A", "A", new Date(), new Date()));
        planAs.add(new ViewPlanDetailDto(2, "B", "B", "B", new Date(), new Date()));
        
        List<ViewPlanDetailDto> planAss = new ArrayList<>();
        planAss.add(new ViewPlanDetailDto(1, "A", "A", "A", new Date(), new Date()));
        planAss.add(new ViewPlanDetailDto(2, "B", "B", "B", new Date(), new Date()));
        assertEquals(planAs, planAss);
	}
	
	
	
	@Test
	public void whenFindAllBy_thenReturnListofViewPlanDetailDto() {
        java.sql.Date startDate = new java.sql.Date(new Date().getTime());
        java.sql.Date endDate = new java.sql.Date(new Date().getTime());
        Plan planA = new Plan();
        planA.setName("Plan A - 2018");
        entityManager.persist(planA);
        entityManager.flush();
        Module moduleA = new Module();
        moduleA.setName("CSS");
        moduleA.setDescription("CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.");
        entityManager.persist(moduleA);
        entityManager.flush();
        Module moduleB = new Module();
        moduleB.setName("HTML");
        moduleB.setDescription("Hypertext Markup Language is the standard markup language for creating web pages and web applications.");
        entityManager.persist(moduleB);
        entityManager.flush();
        PlanDetail planDetailA = new PlanDetail();
        planDetailA.setInstructor("Mozilla Firefox Foundation");
        planDetailA.setStartDate(startDate);
        planDetailA.setEndDate(endDate);
        planDetailA.setModule(moduleA);
        planDetailA.setPlan(planA);
        entityManager.persist(planDetailA);
        entityManager.flush();

        PlanDetail planDetailB = new PlanDetail();
        planDetailB.setInstructor("W3 Schools");
        planDetailB.setStartDate(startDate);
        planDetailB.setEndDate(endDate);
        planDetailB.setModule(moduleB);
        planDetailB.setPlan(planA);
        entityManager.persist(planDetailB);
        entityManager.flush();
        

        List<ViewPlanDetailDto> plandetails = new ArrayList<>();
        plandetails.add(new ViewPlanDetailDto(planDetailA.getId(), planDetailA.getModule().getName(), planDetailA.getModule().getDescription(), planDetailA.getInstructor(), planDetailA.getStartDate(), planDetailA.getEndDate()));
        plandetails.add(new ViewPlanDetailDto(planDetailB.getId(), planDetailB.getModule().getName(), planDetailB.getModule().getDescription(), planDetailB.getInstructor(), planDetailB.getStartDate(), planDetailB.getEndDate()));

        assertThat(plandetails).hasSameSizeAs(planRepository.findAllBy(planA.getId()));
        System.out.println(planRepository.findAllBy(planA.getId()));
        System.out.println(plandetails);
        assertEquals(plandetails, planRepository.findAllBy(planA.getId()));
	}
	
	
	
}
