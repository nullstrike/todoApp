package com.enwan.miniproject.dto;


import java.util.Date;
import lombok.Data;


@Data
public class ViewPlanDetailDto {

    private Integer detailId;

    private String name;
    
    private String description;
    
    private String instructor;
    
    private Date startDate;
    
    private Date endDate;


	public ViewPlanDetailDto(Integer detailId, String name, String description, String instructor, Date startDate,
			Date endDate) {
		this.detailId = detailId;
		this.name = name;
		this.description = description;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}


	

    
}
