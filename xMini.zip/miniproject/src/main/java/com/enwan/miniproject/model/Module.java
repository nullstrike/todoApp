package com.enwan.miniproject.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Set;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "module")
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"})
public class Module extends Auditing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ModuleId")
    private Integer id;

    @Column(name = "ModuleName", nullable = false)
    private String name;

    @Column(name = "Description", nullable = false, columnDefinition = "TEXT")
    private String description;

    @OneToMany(mappedBy = "module", orphanRemoval = true)
    @JsonIgnore
    private Set<PlanDetail> planDetails;

    public Module() { }

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
    }


}

