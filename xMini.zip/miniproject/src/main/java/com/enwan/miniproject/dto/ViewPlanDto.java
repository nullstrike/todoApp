package com.enwan.miniproject.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewPlanDto {
	
	private Integer planID;
	
	private String name;

	public ViewPlanDto(String name) {
		this.name = name;
	}

	public ViewPlanDto() {
	}
	
	
}
