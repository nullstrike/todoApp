package com.enwan.miniproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "user")
public class User extends Auditing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserId")
    private Integer id;

    @Column(name = "FirstName", nullable = false, length = 40)
    private String firstName;

    @Column(name = "MiddleName", length = 40)
    private String middleName;

    @Column(name = "LastName", nullable = false, length = 40)
    private String lastName;

    @Column(name = "Username", nullable = false, length = 20)
    @JsonIgnore
    private String username;

    @Column(name = "Password", nullable = false)
    @JsonIgnore
    private String password;

    @ManyToOne
    @JoinColumn(name = "RoleId", nullable = false)
    @JsonIgnore
    private Role role;

    @OneToMany(mappedBy = "user", orphanRemoval = true)
    @JsonIgnore
    private Set<Task> tasks;

    @OneToMany(mappedBy = "user", orphanRemoval = true)
    @JsonIgnore
    private Set<UserPlan> userPlans;

    public User() { }

	public User(String firstName, String middleName, String lastName, String username, String password, Role role) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.username = username;
		this.password = password;
		this.role = role;
	}



 
}
