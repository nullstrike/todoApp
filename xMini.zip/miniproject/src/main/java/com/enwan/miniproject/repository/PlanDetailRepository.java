package com.enwan.miniproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.enwan.miniproject.dto.PlanDetailDto;
import com.enwan.miniproject.model.PlanDetail;
import com.enwan.miniproject.model.UserStatus;

@Repository
public interface PlanDetailRepository extends JpaRepository<PlanDetail, Integer> {

	@Query("SELECT a FROM UserStatus a join a.planDetail b where b.startDate = CURRENT_DATE AND a.userPlan.id = (SELECT c.id from UserPlan c WHERE c.plan.id = :plan_id and c.user.id = :user_id)")
	List<UserStatus> findOngoingModules(@Param("plan_id") Integer plan_id, @Param("user_id") Integer user_id);

	@Query(" select new com.enwan.miniproject.dto.PlanDetailDto(a.id, a.plan.id, a.plan.name, a.module.id, b.name, b.description, a.instructor, a.startDate, a.endDate) from PlanDetail a join a.module b order by a.plan.id, b.id")
	List<PlanDetailDto> findAllPlanDetail();
	
	
}
