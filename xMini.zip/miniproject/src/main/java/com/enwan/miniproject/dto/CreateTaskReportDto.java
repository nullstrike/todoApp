package com.enwan.miniproject.dto;

import lombok.Data;


@Data
public class CreateTaskReportDto {

	private Integer userId;
	
	private String text;
	
	private String type;

	public CreateTaskReportDto(Integer userId, String text, String type) {
		super();
		this.userId = userId;
		this.text = text;
		this.type = type;
	}

	
}
