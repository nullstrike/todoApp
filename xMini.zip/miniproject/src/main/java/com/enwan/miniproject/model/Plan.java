package com.enwan.miniproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "plan")
public class Plan extends Auditing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PlanId")
    private Integer id;

    @Column(name = "PlanName", nullable = false)
    private String name;

    @OneToMany(mappedBy = "plan", orphanRemoval = true)
    @JsonIgnore
    private Set<UserPlan> userPlans;

    @OneToMany(mappedBy = "plan", orphanRemoval = true)
    @JsonIgnore
    private Set<PlanDetail> planDetails;
    
    public Plan() { }
	
}
