package com.enwan.miniproject.dto;

import lombok.Data;

@Data
public class UserStatusDto {

	private Integer id;
	
	private Integer planId;
	
	private Integer moduleId;
	
	private String moduleName;
	
	private Integer status;

	UserStatusDto() {}
	
	public UserStatusDto(Integer id, Integer planId, Integer moduleId, String moduleName, Integer status) {
		super();
		this.id = id;
		this.planId = planId;
		this.moduleId = moduleId;
		this.moduleName = moduleName;
		this.status = status;
	}
	
}
