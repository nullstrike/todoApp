package com.enwan.miniproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

import java.util.Date;
import java.util.Set;

@Data
@Entity
@Table(name = "plandetail")
public class PlanDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DetailId")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ModuleId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Module module;

    @Column(name = "Instructor", nullable = false)
    private String instructor;

    @Column(name = "StartDate", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name = "EndDate", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @OneToMany(mappedBy = "planDetail", orphanRemoval = true)
    @JsonIgnore
    private Set<UserStatus> userStatuses;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PlanId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Plan plan;
    
    public PlanDetail() { }

    public PlanDetail(Module module, String instructor, Date startDate, Date endDate) {
        this.module = module;
        this.instructor = instructor;
        this.startDate = startDate;
        this.endDate = endDate;
    }


	
}
