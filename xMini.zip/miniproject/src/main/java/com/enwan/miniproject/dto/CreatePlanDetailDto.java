package com.enwan.miniproject.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class CreatePlanDetailDto {

	private List<Integer> userPlanIds;
	
	private Integer planId;
	@NotNull(message = "Current name field should not be null")
	
	private Integer moduleId;
	@NotNull(message = "Current instructor field should not be null")
	@NotEmpty(message = "Current instructor field should not be empty")
	private String instructor;
	@NotNull(message = "Current Start Date field should not be null")
	private Date startDate;
	@NotNull(message = "Current End Date field should not be null")
	private Date endDate;

	public CreatePlanDetailDto() {
	}
	
	public CreatePlanDetailDto(List<Integer> userPlanId, Integer moduleId, String instructor, Date startDate,
			Date endDate) {
		this.userPlanIds = userPlanId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public CreatePlanDetailDto(Integer planId, Integer moduleId, String instructor, Date startDate, Date endDate) {
		this.planId = planId;
		this.moduleId = moduleId;
		this.instructor = instructor;
		this.startDate = startDate;
		this.endDate = endDate;
	}


	

	
}
