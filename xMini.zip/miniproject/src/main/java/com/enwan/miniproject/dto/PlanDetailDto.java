package com.enwan.miniproject.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PlanDetailDto {
	
	private Integer id;
	
	private Integer planId;
	
	private String planName;
	
	private Integer moduleId;
	
	private String name; 
	
	private String description;
	
	private String instructor;
	
	private Date startDate;
	
	private Date endDate;	

}
