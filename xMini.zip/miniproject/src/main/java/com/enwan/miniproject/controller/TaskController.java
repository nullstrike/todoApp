package com.enwan.miniproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.CreateTaskReportDto;
import com.enwan.miniproject.model.Task;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.TraineeService;

@RestController
@RequestMapping("/api/report")
public class TaskController {
	
	private final TraineeService traineeService;
	
	@Autowired
	public TaskController(TraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@PostMapping
	public ResponseEntity<?> addReport(@Valid @RequestBody List<CreateTaskReportDto> taskReportDto) {
		traineeService.saveTask(taskReportDto);
		return ResponseEntity.ok(new RequestResponse(true, "Successfully created daily report."));
	}
	
	@GetMapping
	public List<Task> dailyReports() {
		return traineeService.getAllTasks();
	}	
}
