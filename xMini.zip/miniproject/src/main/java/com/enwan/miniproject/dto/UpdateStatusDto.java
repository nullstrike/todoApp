package com.enwan.miniproject.dto;

import lombok.Data;

@Data
public class UpdateStatusDto {

	Integer user;
	
	Integer module;
	
	Boolean isChecked;

	public UpdateStatusDto(Integer user, Integer module, Boolean isChecked) {
		super();
		this.user = user;
		this.module = module;
		this.isChecked = isChecked;
	}
	
	public UpdateStatusDto(){};
	
}
