package com.enwan.miniproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;
import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@Table(name = "role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RoleId")
    private Integer id;

    @Column(name = "RoleName")
    private String roleName;

    @OneToMany(mappedBy = "role")
    @JsonIgnore
    private Set<User> users;

    public Role() {
    }


}
