   $(function() {
	   $.ajaxSetup({ cache: false });
	   var currentDate = moment().format('YYYY-MM-DD');
	   var tt = [];
	   var user_id = parseInt($("#user_id").text());
	   
	   var empty_template = '<tr class="task_placeholder header">' +
		'<td>Nothing to show here...</td>'	+
			'</tr>';
	    
	    getUserReport(user_id);
        $('#calendar').fullCalendar({
        	selectable: true,
        	dayClick: function(date){
        		
        		checkDate(date);
        		
        		$("#view_completed_list tbody, #view_challenge_list tbody, #view_todo_list tbody").each(function() {
        			$(this).find("tr").remove();
        			$(this).append(empty_template);
        		});
        		
        		enumerateLists(date.format());
        		
        	},
        	dayRender: function(date, cell) {
        		  // Allow keyboard to access and interact with calendar days
        		  $(cell).attr("tabindex", "0").on("keydown", function(e) {
        		    if (e.which === 32 || e.which === 13) {
        		      var day = $(this);
        		      var down = new $.Event("mousedown");
        		      var up = new $.Event("mouseup");
        		      var eventParams = { which: 1, pageX: day.offset().left, pageY: day.offset().top };

        		      day.trigger($.extend(true, {}, down, eventParams));
        		      day.trigger($.extend(true, {}, up, eventParams));
        		    }
        		  });
        		}

        });
       
    
        
        $('#add_task').on('click', function() {
			var task = $("textarea[name=task]");
			var type  = $("select").val();
			var template = '<tr class="tasks_lists">' +
            					'<td name="task" class="" style="width:75%" data-task-type="'+ type + '">' + task.val() + '</td>' +
            					'<td class="" style="width:25%">' + '<a href="javascript:void(0)" class="btn btn-sm task_edit"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>' +
            					'<a href="javascript:void(0)" class="btn btn-sm task_save" style="display:none;"><i class="dropdown-icon fe fe-save"></i> Save </a>' +
        						
            					'<a href="javascript:void(0)" class="btn btn-sm  task_delete text-danger"><i class="dropdown-icon fe fe-trash" ></i> Delete </a>' + '</td>' + 
        				
           					'</tr>';
	
           	if (!$.trim($("#task").val())) {
				alert("task should not be empty");
			} else {
				if (type === "Done"){
					$("#complete_list").append(template).find("tr.task_placeholder").remove();
				}
				
				if (type === "Challenges") {
					$("#challenge_list").append(template).find("tr.task_placeholder").remove();
				}
				
				if (type === "Todo") {
					$("#todo_list").append(template).find("tr.task_placeholder").remove();
				}
				task.val("");
			} 
		});
        
        $("#task_type").change(function(){
        	var value = $(this).val();
        	
        	switch(value){
        		case "Done":
        			$('a[href="#task_completed"]').click();
        			break;
        		case "Challenges":
        			$('a[href="#task_challenge"]').click();
        			break;
        		case "Todo":
        			$('a[href="#task_todo"]').click();
        			break;
        	}
        });
        
        $("table tbody").on("click", ".task_edit", function() {
        	var val = $(this).closest("tr").find("td:first").text();
        	$(this).closest("tr").find("td:first").html("<textarea class='form-control' autocomplete='off'>" + val + "</textarea>");
        	$(this).hide();
        	$(this).closest("tr").find(".task_save").show();
        });
        
        $("table tbody").on("click", ".task_save", function () {
        	var parent = $(this).closest("tr");
        	var val = parent.find("textarea").val();
        	parent.find("td:first").html(val);
        	$(this).hide();
        	parent.find(".task_edit").show();
        });
        
        $("table tbody").on("click", ".task_delete", function() {
        	var temp = $(this).closest("tr").parent();
        	var row_count = $(this).closest("tr").parent();
        	$(this).closest("tr").remove();
        	if (row_count[0].children.length === 0){
        		temp.append(empty_template);
        	}
        });
        
        
        $("#addReportButton").on("click", function() {
     	   var user_id = parseInt($("#user_id").text());
     	   var data = [];
     	   
        	$("#complete_list tbody > tr.tasks_lists, #challenge_list tbody > tr.tasks_lists , #todo_list tbody > tr.tasks_lists").each(function(index, element) {
        		var content = $(this).closest("tr").find("[name='task']");
        		var type = content.data('task-type');
        		
        		var dataContainer = {
        				text: content.text(),
           				type: type,
           				userId: user_id,
           		}
        	
        		data.push(dataContainer);
        	});
        	
        	if (data.length === 0){
        		swal({
        			title: "Daily report creation",
        			text: "Daily report cannot be empty",
        			type: "warning"
        		});
        	} else {
            	$.ajax({
    				url : 'http://localhost:8080/api/report',
    				type : 'POST', // 
    				contentType : "application/json",
    				data : JSON.stringify(data),
    				dataType : 'json',
    				success : function(response) {
    					swal({
    	        			title: "Daily report creation",
    	        			text: response.message,
    	        			type: "success"
    	        		});
    					getUserReport(user_id);
    					$("#task_modal").modal('hide');
    				},
    				error: function(response){
    					swal({
    	        			title: "Daily report creation",
    	        			text: "An error occured.",
    	        			type: "error"
    	        		});
    				}
    			});
        	}

        	
        });
        
        function resetTables(){
        	var placeholder = '<tr class="task_placeholder header"> ' + 
                    						'<td>Nothing to show here...</td>' +	
                   						'</tr>';
        	
        	$("#complete_list, #challenge_list, #todo_list").find("tbody").html(placeholder);
        }
        
        $("#task_modal").on("hidden.bs.modal", function() {
        	resetTables();
        });
        
        function getUserReport(user_id){
            $.ajax({
    			url : "http://localhost:8080/api/user/report/" + user_id,
    			contentType : "application/json",
    			type : "get",
    			success : function(response) {
    				tt = response;
    			}
            });
        }
        
        function templateOfRows(task){
        	var template = '<tr class="tasks_lists" >' +
				'<td style="width:75%">' + task + '</td>' +
		   '</tr>';
        	
        	return template;
        }
        
        function checkDate(date){
			if(date.format()!== currentDate) $("#createReport").hide();
			else $("#createReport").show();
        }
        
        function enumerateLists(date){
        	
        	for (i=0; i<tt.length; i++){
        		
        		if(tt[i].taskDate === date){
					
					switch(tt[i].taskType){
					case "Done": {
						if(tt[i].content)
							$("#view_completed_list").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				
					case "Challenges":{
						if(tt[i].content)
							$("#view_challenge_list").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				
					case "Todo": {
						if(tt[i].content)
							$("#view_todo_list").append(templateOfRows(tt[i].content)).find("tr.task_placeholder").remove();
						break;
					}
				}

				}
			}
        }
});