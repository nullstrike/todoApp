$(function () {
	
	 var user_name = $('#user_name').text();	
	 $("span.avatar").addClass('avatar-' + colorize()).text(user_name.charAt(0) + user_name.charAt(user_name.lastIndexOf(' ') + 1));
		

	//performs logout action
	$("#logOut").on("click", function() {
		$("#logoutForm").submit();
	});
	
	//performs change password action
	$("#changePasswordButton").on('click', function(event) {
		event.preventDefault();
		var form = $('#changePasswordForm');
		$.ajax({
			url: "http://localhost:8080/api/user",
			type: "put",
			contentType: "application/json",
			dataType: "json",
			data: transformToJSON(form),
			success: function(response){
				$("#changePasswordModal").modal('hide');
				swal({
					title: "Updating password", 
					text: response.message, 
					type: "success",
					backdrop: false
				});
			},
			error: function(errors){
				var fieldErrors = errors.responseJSON.errors;
				var otherErrors = errors.responseJSON;
				if (! otherErrors.success){
					console.log(otherErrors);
					$('input[name=currentPassword]').removeClass('is-valid').addClass('is-invalid').next().next().html(otherErrors.message);
				}
				for (var fieldError in fieldErrors){
					/*if (fieldError === 'changePasswordDto'){
						$('input[name=newPassword], input[name=confirmPassword]').removeClass('is-valid').addClass('is-invalid').next().next().html(fieldErrors[fieldError]);
					}*/
					$('input[name=' + fieldError + ']').removeClass('is-valid').addClass('is-invalid').next().next().html(fieldErrors[fieldError]);
				}
			}
		});
	});
	
	$('#changePasswordForm input').on("blur",function(){

		if( $(this).val().length >= 8 ) {
			 $(this).removeClass('is-invalid').addClass('is-valid');
		} else {
			 $(this).removeClass("is-valid").addClass('is-invalid');
	    }
   
	});
	
	$("#changePasswordModal").on("hidden.bs.modal", function(e){
		$(this).find("input").each(function(index, input){
			var element = $(input);
			if (element.attr("type") === "hidden"){
				return;
			}
			$(input).val("").removeClass("is-valid is-invalid");
			
		});
	});
});

function transformToJSON(form){
	var data = {};
	
	form.serializeArray().map(function(input){
		data[input.name] = input.value;
	});
	
	return JSON.stringify(data);
}

function colorize()	{
	var colors = [
	       "blue",
	       "azure",
	       "indigo",
	       "purple",
	       "pink",
	       "red",
	       "orange",
	       "yellow",
	       "lime",
	       "green",
	       "teal",
	       "cyan",
	       "gray",
	       "gray-dark"
	];
	
	return colors[parseInt((Math.random() * colors.length) + 1)];
}